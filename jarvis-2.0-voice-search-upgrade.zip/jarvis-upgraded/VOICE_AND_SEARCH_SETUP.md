# JARVIS 2.0 — Voice & Live Search Upgrade

## What changed

- Android now uses `MediaRecorder` to capture a short voice turn, then sends it to the new `/api/transcribe` endpoint for Gemini audio transcription. This avoids depending on the limited `SpeechRecognition` implementation on Android browsers.
- Desktop browsers continue to use Web Speech recognition when available; network/language failures fall back to audio recording.
- Hindi, English and Hinglish transcription instructions are selected from the voice-language control.
- Search requests now use Tavily's Bearer-token authentication, stronger live-search intent detection, timeouts and explicit errors.
- The app no longer silently answers from model memory when a requested live search fails.
- Deprecated Gemini 1.5/2.0 defaults were replaced with `gemini-3.8-flash` and `gemini-3.5-flash-lite` options.

## Configure keys

1. Create a Gemini API key at https://aistudio.google.com/apikey
2. Create a Tavily key at https://app.tavily.com/
3. In JARVIS, open Settings, paste both keys and press **Save Credentials**.
4. Press **Test Web Search** to verify Tavily.
5. For server deployment, copy `.env.example` to `.env.local` and configure:
   - `GEMINI_API_KEY`
   - `GEMINI_MODEL=gemini-3.8-flash`
   - `GEMINI_TRANSCRIPTION_MODEL=gemini-3.8-flash`
   - `TAVILY_API_KEY`

The keys entered in Settings are kept in browser local storage and sent to the same-origin backend only when needed. For a public multi-user deployment, prefer server-side environment variables and implement authenticated per-user secret storage rather than relying on local storage.

## Android microphone requirements

- Open the deployed site over HTTPS. `http://localhost` is allowed for local development, but an ordinary HTTP LAN/IP address is not a secure context.
- In the browser's site settings, allow Microphone.
- Tap the microphone once to begin recording; tap it again to stop and transcribe. Wait for the transcription to finish before sending another voice command.
- The Android recording fallback requires a working Gemini API key, either saved in Settings or configured as `GEMINI_API_KEY` on the server.
- Keep each recording short (roughly under one minute) to avoid large requests and quota/time limits.
- If the browser reports permission denied, open Android app settings > browser > Permissions > Microphone and allow it.

## Live web search

Tavily requires an API key; this project cannot legally or technically access a private API account without its key. The free allocation/limits are controlled by Tavily and may change. Search requests such as "latest AI news", "search the web for...", "aaj ki latest khabar", "current price" and "real-time update" now trigger live search. A failed or unconfigured search is surfaced to the user instead of being presented as a live answer.

## Run locally

```bash
npm install
cp .env.example .env.local
npm run dev
```

Then open http://localhost:3000. For production, deploy the Next.js app to a host that supports Node.js route handlers and configure environment variables in the host dashboard.

## Verification note

This archive was inspected and patched, but a full production build and live microphone/API integration test could not be completed in this environment because the ZIP does not include `node_modules` and no user API credentials were supplied. Run `npm install`, `npm run typecheck`, and `npm run build` locally after configuring the keys.
