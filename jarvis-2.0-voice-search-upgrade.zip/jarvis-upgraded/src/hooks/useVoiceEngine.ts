"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { VoiceLanguage } from "@/types/jarvis";
import { audioAnalyzer } from "@/services/audio/audioAnalyzer";

interface UseVoiceEngineProps {
  onTranscriptReady: (transcript: string, detectedLang?: string) => void;
  wakeWord?: string;
  wakeWordEnabled?: boolean;
  apiKey?: string;
}

type SpeechRecognitionLike = any;

export function useVoiceEngine({
  onTranscriptReady,
  wakeWord = "jarvis",
  wakeWordEnabled = false,
  apiKey,
}: UseVoiceEngineProps) {
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [interimTranscript, setInterimTranscript] = useState("");
  const [speechLanguage, setSpeechLanguage] = useState<VoiceLanguage>("auto");
  const [selectedVoice, setSelectedVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [availableVoices, setAvailableVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [speechRate, setSpeechRate] = useState(1.0);
  const [speechPitch, setSpeechPitch] = useState(1.0);
  const [speechVolume, setSpeechVolume] = useState(1.0);
  const [isSpeechSupported, setIsSpeechSupported] = useState(true);
  const [isRecSupported, setIsRecSupported] = useState(true);
  const [continuousMode, setContinuousMode] = useState(false);
  const [voiceError, setVoiceError] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognitionLike>(null);
  const synthesisRef = useRef<SpeechSynthesis | null>(null);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const recordingStreamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const callbackRef = useRef(onTranscriptReady);
  const apiKeyRef = useRef(apiKey || "");
  const manuallyStoppedRef = useRef(false);
  const isListeningRef = useRef(false);
  const continuousRef = useRef(continuousMode);
  const wakeRef = useRef({ wakeWord, wakeWordEnabled });
  const languageRef = useRef(speechLanguage);

  callbackRef.current = onTranscriptReady;
  apiKeyRef.current = apiKey || "";
  continuousRef.current = continuousMode;
  wakeRef.current = { wakeWord, wakeWordEnabled };
  languageRef.current = speechLanguage;
  isListeningRef.current = isListening;

  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("speechSynthesis" in window)) {
      setIsSpeechSupported(false);
      return;
    }

    synthesisRef.current = window.speechSynthesis;
    const updateVoices = () => {
      const voices = synthesisRef.current?.getVoices() || [];
      setAvailableVoices(voices);
      const preferred =
        voices.find((v) => v.lang.toLowerCase() === "hi-in") ||
        voices.find((v) => v.lang.toLowerCase() === "en-in") ||
        voices.find((v) => v.lang.toLowerCase().startsWith("en")) ||
        voices[0];
      if (preferred) setSelectedVoice((current) => current || preferred);
    };

    updateVoices();
    synthesisRef.current.onvoiceschanged = updateVoices;
    return () => {
      if (synthesisRef.current) synthesisRef.current.onvoiceschanged = null;
    };
  }, []);

  const deliverTranscript = useCallback((raw: string) => {
    const cleaned = raw.trim();
    if (!cleaned) return;
    setTranscript(cleaned);
    setInterimTranscript("");
    const { wakeWord: word, wakeWordEnabled: enabled } = wakeRef.current;
    if (enabled && word.trim()) {
      const escaped = word.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const match = cleaned.match(new RegExp(escaped, "i"));
      if (!match) return;
      const command = cleaned.slice((match.index || 0) + match[0].length).trim();
      if (command) callbackRef.current(command);
      else callbackRef.current(cleaned);
    } else {
      callbackRef.current(cleaned);
    }
  }, []);

  const stopRecorderTracks = useCallback(() => {
    recordingStreamRef.current?.getTracks().forEach((track) => track.stop());
    recordingStreamRef.current = null;
  }, []);

  const startRecorderFallback = useCallback(async () => {
    if (typeof window === "undefined") return;
    if (!window.isSecureContext && location.hostname !== "localhost") {
      setVoiceError("Microphone access ke liye website HTTPS par honi chahiye. Localhost bhi supported hai.");
      setIsListening(false);
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      setVoiceError("Is browser mein microphone recording supported nahi hai. Updated Chrome use karein.");
      setIsListening(false);
      return;
    }

    try {
      setVoiceError(null);
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      recordingStreamRef.current = stream;
      chunksRef.current = [];

      const mimeCandidates = [
        "audio/webm;codecs=opus",
        "audio/webm",
        "audio/mp4",
        "audio/ogg;codecs=opus",
      ];
      const mimeType = mimeCandidates.find((type) => MediaRecorder.isTypeSupported(type));
      const recorder = mimeType ? new MediaRecorder(stream, { mimeType }) : new MediaRecorder(stream);
      recorderRef.current = recorder;

      recorder.ondataavailable = (event: BlobEvent) => {
        if (event.data && event.data.size > 0) chunksRef.current.push(event.data);
      };

      recorder.onerror = () => {
        setVoiceError("Microphone recording mein error aaya. Permission check karke dobara try karein.");
        setIsListening(false);
        stopRecorderTracks();
      };

      recorder.onstop = async () => {
        setIsListening(false);
        stopRecorderTracks();
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        chunksRef.current = [];
        recorderRef.current = null;

        if (blob.size < 1200) {
          setInterimTranscript("");
          setVoiceError("Koi clear speech record nahi hui. Mic dabakar dobara boliye.");
          return;
        }

        setInterimTranscript("Audio transcribing...");
        try {
          const buffer = await blob.arrayBuffer();
          const bytes = new Uint8Array(buffer);
          let binary = "";
          const chunkSize = 0x8000;
          for (let i = 0; i < bytes.length; i += chunkSize) {
            binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
          }
          const audioBase64 = btoa(binary);

          const response = await fetch("/api/transcribe", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              audioBase64,
              mimeType: blob.type || "audio/webm",
              language: languageRef.current,
              apiKey: apiKeyRef.current || undefined,
            }),
          });
          const data = await response.json();
          if (!response.ok) throw new Error(data.error || `Transcription failed (${response.status})`);
          if (!data.transcript?.trim()) throw new Error("Speech samajh nahi aayi. Thoda paas se aur clearly boliye.");
          setVoiceError(null);
          deliverTranscript(data.transcript);
        } catch (error) {
          setVoiceError(error instanceof Error ? error.message : "Voice transcription failed.");
        } finally {
          setInterimTranscript("");
        }
      };

      recorder.start(300);
      setIsListening(true);
      setInterimTranscript("Listening… bolne ke baad microphone dobara dabayein.");
    } catch (error) {
      setIsListening(false);
      const message = error instanceof Error ? error.message : "Microphone permission failed.";
      setVoiceError(
        message.includes("NotAllowed") || message.includes("Permission")
          ? "Microphone permission blocked hai. Browser site settings mein Microphone ko Allow karein."
          : `Microphone start nahi hua: ${message}`
      );
    }
  }, [deliverTranscript, stopRecorderTracks]);

  const startListening = useCallback(async () => {
    if (isListeningRef.current) return;
    manuallyStoppedRef.current = false;
    setVoiceError(null);
    setInterimTranscript("");
    if (synthesisRef.current) synthesisRef.current.cancel();
    setIsSpeaking(false);
    audioAnalyzer.stopSpeechAudioSimulation();

    const isAndroid = typeof navigator !== "undefined" && /Android/i.test(navigator.userAgent);
    const SpeechRec =
      typeof window !== "undefined"
        ? (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
        : null;

    // Chrome Android and several embedded/mobile browsers do not expose a reliable
    // SpeechRecognition implementation. Record audio and transcribe it server-side instead.
    if (!SpeechRec || isAndroid) {
      setIsRecSupported(false);
      await startRecorderFallback();
      return;
    }

    try {
      const rec: SpeechRecognitionLike = new SpeechRec();
      recognitionRef.current = rec;
      rec.continuous = continuousRef.current;
      rec.interimResults = true;
      rec.maxAlternatives = 1;
      rec.lang =
        languageRef.current === "hi"
          ? "hi-IN"
          : languageRef.current === "en"
            ? "en-IN"
            : "en-IN";

      rec.onstart = () => {
        setIsListening(true);
        setVoiceError(null);
        audioAnalyzer.connectMicrophone().catch(() => {});
      };

      rec.onresult = (event: any) => {
        let finalText = "";
        let interimText = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const item = event.results[i];
          const text = item?.[0]?.transcript || "";
          if (item.isFinal) finalText += text;
          else interimText += text;
        }
        if (interimText) setInterimTranscript(interimText);
        if (finalText.trim()) {
          deliverTranscript(finalText);
          if (!continuousRef.current) {
            manuallyStoppedRef.current = true;
            setIsListening(false);
            audioAnalyzer.disconnectMicrophone();
            try { rec.stop(); } catch {}
          }
        }
      };

      rec.onerror = (event: any) => {
        const code = event?.error || "unknown";
        console.warn("Speech recognition error:", code);
        if (code === "not-allowed" || code === "service-not-allowed") {
          setVoiceError("Speech recognition permission/service blocked. Microphone permission allow karein; Android par audio transcription fallback use hota hai.");
          setIsListening(false);
          audioAnalyzer.disconnectMicrophone();
        } else if (code === "network" || code === "language-not-supported") {
          manuallyStoppedRef.current = true;
          setIsListening(false);
          audioAnalyzer.disconnectMicrophone();
          startRecorderFallback();
        } else if (code !== "no-speech" && code !== "aborted") {
          setVoiceError(`Speech recognition error: ${code}`);
          setIsListening(false);
          audioAnalyzer.disconnectMicrophone();
        }
      };

      rec.onend = () => {
        audioAnalyzer.disconnectMicrophone();
        if (continuousRef.current && !manuallyStoppedRef.current) {
          window.setTimeout(() => {
            try {
              rec.start();
            } catch {
              setIsListening(false);
            }
          }, 250);
        } else {
          setIsListening(false);
        }
      };

      rec.start();
      setIsListening(true);
    } catch (error) {
      console.warn("SpeechRecognition unavailable; using audio transcription fallback.", error);
      setIsListening(false);
      await startRecorderFallback();
    }
  }, [deliverTranscript, startRecorderFallback]);

  const stopListening = useCallback(() => {
    manuallyStoppedRef.current = true;
    const recorder = recorderRef.current;
    if (recorder && recorder.state !== "inactive") {
      recorder.stop();
      return;
    }
    setIsListening(false);
    setInterimTranscript("");
    audioAnalyzer.disconnectMicrophone();
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch {}
      recognitionRef.current = null;
    }
  }, []);

  const speak = useCallback(
    (text: string) => {
      if (typeof window === "undefined" || !synthesisRef.current || isMuted) return;
      synthesisRef.current.cancel();
      audioAnalyzer.stopSpeechAudioSimulation();

      const cleaned = text
        .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
        .replace(/[*#_`~>-]/g, " ")
        .replace(/\n+/g, ". ")
        .trim();
      if (!cleaned) return;

      const utterance = new SpeechSynthesisUtterance(cleaned);
      utterance.rate = speechRate;
      utterance.pitch = speechPitch;
      utterance.volume = speechVolume;

      const hasDevanagari = /[\u0900-\u097F]/.test(cleaned);
      const isHindi =
        hasDevanagari ||
        (speechLanguage === "hi" && /(namaste|dhanyawad|shukriya|kya|hai|karo|batao|aaj)/i.test(cleaned));
      const voice = isHindi
        ? availableVoices.find((v) => v.lang.toLowerCase().startsWith("hi")) ||
          availableVoices.find((v) => v.lang.toLowerCase() === "en-in")
        : availableVoices.find((v) => v.lang.toLowerCase() === "en-in") ||
          availableVoices.find((v) => v.lang.toLowerCase().startsWith("en")) ||
          selectedVoice;
      if (voice) {
        utterance.voice = voice;
        utterance.lang = voice.lang;
      } else {
        utterance.lang = isHindi ? "hi-IN" : "en-IN";
      }

      utterance.onstart = () => {
        setIsSpeaking(true);
        audioAnalyzer.startSpeechAudioSimulation(cleaned);
      };
      utterance.onend = () => {
        setIsSpeaking(false);
        audioAnalyzer.stopSpeechAudioSimulation();
      };
      utterance.onerror = (event) => {
        console.warn("Speech synthesis error:", event);
        setIsSpeaking(false);
        audioAnalyzer.stopSpeechAudioSimulation();
      };
      synthesisRef.current.speak(utterance);
    },
    [isMuted, speechRate, speechPitch, speechVolume, selectedVoice, availableVoices, speechLanguage]
  );

  const stopSpeaking = useCallback(() => {
    synthesisRef.current?.cancel();
    setIsSpeaking(false);
    audioAnalyzer.stopSpeechAudioSimulation();
  }, []);

  useEffect(() => {
    return () => {
      manuallyStoppedRef.current = true;
      try {
        recognitionRef.current?.abort?.();
        if (recorderRef.current && recorderRef.current.state !== "inactive") recorderRef.current.stop();
      } catch {}
      stopRecorderTracks();
      audioAnalyzer.disconnectMicrophone();
      synthesisRef.current?.cancel();
    };
  }, [stopRecorderTracks]);

  return {
    isListening,
    isSpeaking,
    isMuted,
    setIsMuted,
    transcript,
    interimTranscript,
    speechLanguage,
    setSpeechLanguage,
    selectedVoice,
    setSelectedVoice,
    availableVoices,
    speechRate,
    setSpeechRate,
    speechPitch,
    setSpeechPitch,
    speechVolume,
    setSpeechVolume,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    isSpeechSupported,
    isRecSupported,
    continuousMode,
    setContinuousMode,
    voiceError,
  };
}
