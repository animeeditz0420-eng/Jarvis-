"use client";

import React, { useState } from "react";
import { Mic, MicOff, Send, Radio, Sparkles, VolumeX } from "lucide-react";
import { VoiceLanguage } from "@/types/jarvis";

interface BottomControlsProps {
  isListening: boolean;
  isSpeaking: boolean;
  voiceError?: string | null;
  onStartListening: () => void;
  onStopListening: () => void;
  onSendMessage: (text: string) => void;
  onStopSpeaking: () => void;
  language: VoiceLanguage;
  onLanguageChange: (lang: VoiceLanguage) => void;
  continuousMode: boolean;
  onToggleContinuous: () => void;
  disabled?: boolean;
}

export default function BottomControls({
  isListening,
  isSpeaking,
  voiceError,
  onStartListening,
  onStopListening,
  onSendMessage,
  onStopSpeaking,
  language,
  onLanguageChange,
  continuousMode,
  onToggleContinuous,
  disabled = false,
}: BottomControlsProps) {
  const [inputText, setInputText] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() || disabled) return;
    onSendMessage(inputText.trim());
    setInputText("");
  };

  const quickPrompts = [
    "Jarvis, aaj internet par AI ki latest news search karo",
    "Jarvis, explain quantum physics in simple Hindi",
    "Calculate 450 * 18.5",
    "Set a timer for 3 minutes",
    "What is the current date and time?",
  ];

  return (
    <footer className="relative z-30 w-full px-4 py-3 bg-slate-950/85 backdrop-blur-md border-t border-cyan-500/20 flex flex-col items-center gap-2.5">
      {/* Quick Prompt Chips */}
      <div className="w-full max-w-4xl flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] font-mono no-scrollbar">
        <span className="text-slate-500 shrink-0 flex items-center gap-1 text-[10px]">
          <Sparkles className="w-3 h-3 text-cyan-400" /> PROMPTS:
        </span>
        {quickPrompts.map((p, idx) => (
          <button
            key={idx}
            onClick={() => onSendMessage(p)}
            className="px-2.5 py-1 rounded-full bg-slate-900/60 hover:bg-cyan-950/50 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-200 transition-colors shrink-0 truncate max-w-[280px]"
          >
            {p}
          </button>
        ))}
      </div>

      {voiceError && (
        <div role="status" className="w-full max-w-3xl text-center text-[11px] text-amber-300 bg-amber-950/30 border border-amber-500/30 rounded-lg px-3 py-2">
          {voiceError}
        </div>
      )}

      {/* Main Interaction Bar */}
      <div className="w-full max-w-3xl flex items-center justify-between gap-3">
        {/* Language & Continuous Listening Options */}
        <div className="flex items-center gap-1.5">
          <div className="flex bg-slate-900/80 p-0.5 rounded-lg border border-slate-800 text-[10px] font-mono">
            {(["auto", "hi", "en"] as VoiceLanguage[]).map((lang) => (
              <button
                key={lang}
                onClick={() => onLanguageChange(lang)}
                className={`px-2 py-1 rounded-md uppercase font-bold transition-all ${
                  language === lang
                    ? "bg-cyan-500 text-slate-950 shadow-[0_0_8px_rgba(0,242,254,0.4)]"
                    : "text-slate-400 hover:text-slate-200"
                }`}
                title={`Language: ${lang === "auto" ? "Hinglish / Auto" : lang === "hi" ? "Hindi (हिंदी)" : "English"}`}
              >
                {lang === "auto" ? "HINGLISH" : lang === "hi" ? "हिंदी" : "EN"}
              </button>
            ))}
          </div>

          <button
            onClick={onToggleContinuous}
            className={`hidden sm:flex items-center gap-1 px-2 py-1.5 rounded-lg border text-[10px] font-mono transition-colors ${
              continuousMode
                ? "bg-cyan-950/60 border-cyan-500/50 text-cyan-300"
                : "bg-slate-900/40 border-slate-800 text-slate-500 hover:text-slate-300"
            }`}
            title="Toggle Continuous Conversation Loop"
          >
            <Radio className="w-3 h-3" />
            <span>{continuousMode ? "CONT ON" : "CONT OFF"}</span>
          </button>
        </div>

        {/* Center Large Glowing Microphone Button */}
        <div className="relative flex items-center justify-center">
          {/* Animated concentric pulses when listening */}
          {isListening && (
            <>
              <div className="absolute w-16 h-16 rounded-full border border-cyan-400/40 animate-ping pointer-events-none" />
              <div className="absolute w-20 h-20 rounded-full border border-cyan-400/20 animate-pulse pointer-events-none" />
            </>
          )}

          <button
            onClick={isListening ? onStopListening : onStartListening}
            disabled={disabled}
            className={`relative w-14 h-14 rounded-full flex items-center justify-center transition-all shadow-xl select-none ${
              isListening
                ? "bg-cyan-400 text-slate-950 shadow-[0_0_28px_rgba(0,242,254,0.8)] scale-110"
                : isSpeaking
                ? "bg-emerald-500/20 text-emerald-400 border-2 border-emerald-400/60 hover:bg-emerald-500/30"
                : "bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-300 border-2 border-cyan-500/50 hover:border-cyan-400 shadow-[0_0_15px_rgba(0,242,254,0.25)]"
            }`}
            title={isListening ? "Listening... Click to stop" : "Click to speak with JARVIS"}
          >
            {isListening ? (
              <MicOff className="w-6 h-6 animate-pulse" />
            ) : isSpeaking ? (
              <VolumeX className="w-6 h-6 text-emerald-300" onClick={onStopSpeaking} />
            ) : (
              <Mic className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Text Input Fallback with Send Button */}
        <form onSubmit={handleSubmit} className="flex-1 max-w-md flex items-center gap-1.5">
          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Type a command in Hindi or English..."
            disabled={disabled}
            className="flex-1 px-3 py-2 rounded-xl bg-slate-900/80 border border-slate-800 focus:border-cyan-500/50 focus:outline-none focus:ring-1 focus:ring-cyan-500/30 text-xs text-slate-100 placeholder:text-slate-500 font-sans"
          />
          <button
            type="submit"
            disabled={!inputText.trim() || disabled}
            className="p-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 disabled:opacity-30 disabled:pointer-events-none text-slate-950 transition-colors shadow-md"
            title="Send Message"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </footer>
  );
}
