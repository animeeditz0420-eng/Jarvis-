"use client";

import React, { useState, useEffect } from "react";
import { SystemStatusData } from "@/types/jarvis";
import {
  X,
  Key,
  Cpu,
  Globe,
  CheckCircle2,
  AlertCircle,
  Volume2,
  Sliders,
  Radio,
  ExternalLink,
  ShieldCheck,
} from "lucide-react";

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  systemStatus: SystemStatusData;
  onRefreshStatus: () => void;
  customGeminiKey: string;
  onSaveGeminiKey: (key: string) => void;
  customTavilyKey: string;
  onSaveTavilyKey: (key: string) => void;
  selectedModel: string;
  onSelectModel: (model: string) => void;
  wakeWord: string;
  onSaveWakeWord: (word: string) => void;
  wakeWordEnabled: boolean;
  onToggleWakeWord: (enabled: boolean) => void;
  speechRate: number;
  onChangeSpeechRate: (rate: number) => void;
  speechPitch: number;
  onChangeSpeechPitch: (pitch: number) => void;
  availableVoices: SpeechSynthesisVoice[];
  selectedVoice: SpeechSynthesisVoice | null;
  onSelectVoice: (voice: SpeechSynthesisVoice) => void;
}

export default function SettingsModal({
  isOpen,
  onClose,
  systemStatus,
  onRefreshStatus,
  customGeminiKey,
  onSaveGeminiKey,
  customTavilyKey,
  onSaveTavilyKey,
  selectedModel,
  onSelectModel,
  wakeWord,
  onSaveWakeWord,
  wakeWordEnabled,
  onToggleWakeWord,
  speechRate,
  onChangeSpeechRate,
  speechPitch,
  onChangeSpeechPitch,
  availableVoices,
  selectedVoice,
  onSelectVoice,
}: SettingsModalProps) {
  const [geminiKeyInput, setGeminiKeyInput] = useState(customGeminiKey);
  const [tavilyKeyInput, setTavilyKeyInput] = useState(customTavilyKey);
  const [wakeWordInput, setWakeWordInput] = useState(wakeWord);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [testResult, setTestResult] = useState<string | null>(null);
  const [isTesting, setIsTesting] = useState(false);

  useEffect(() => {
    setGeminiKeyInput(customGeminiKey);
    setTavilyKeyInput(customTavilyKey);
    setWakeWordInput(wakeWord);
  }, [customGeminiKey, customTavilyKey, wakeWord]);

  if (!isOpen) return null;

  const handleSaveKeys = () => {
    onSaveGeminiKey(geminiKeyInput.trim());
    onSaveTavilyKey(tavilyKeyInput.trim());
    onSaveWakeWord(wakeWordInput.trim());
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2500);
    onRefreshStatus();
  };

  const handleTestTavily = async () => {
    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: "AI breakthrough 2026",
          apiKey: tavilyKeyInput || undefined,
          maxResults: 2,
        }),
      });
      const data = await res.json();
      if (res.ok && data.status === "success") {
        setTestResult(`Tavily Connected successfully! Found ${data.results?.length || 0} live results.`);
      } else {
        setTestResult(`Search notice: ${data.errorMessage || data.error || "Please check your key."}`);
      }
    } catch (e: any) {
      setTestResult(`Connection test error: ${e.message}`);
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md font-mono text-xs select-none">
      <div className="w-full max-w-xl bg-slate-950 border border-cyan-500/30 rounded-2xl shadow-2xl p-5 flex flex-col gap-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-cyan-500/20">
          <div className="flex items-center gap-2">
            <Key className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-sm tracking-wider text-cyan-200">
              JARVIS 2.0 CONFIGURATION
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-cyan-300"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Integration Status Badges */}
        <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col gap-2">
          <span className="text-[11px] font-bold text-slate-400 flex items-center justify-between">
            <span>LIVE INTEGRATION STATUS</span>
            <button
              onClick={onRefreshStatus}
              className="text-cyan-400 hover:underline text-[10px]"
            >
              [Refresh Status]
            </button>
          </span>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
            {/* Gemini Status */}
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Cpu className="w-3.5 h-3.5 text-cyan-400" />
                Gemini API
              </span>
              <span
                className={`px-1.5 py-0.5 rounded font-bold ${
                  systemStatus.aiStatus === "connected"
                    ? "bg-emerald-500/20 text-emerald-300"
                    : "bg-amber-500/20 text-amber-300"
                }`}
              >
                {systemStatus.aiStatus === "connected" ? "CONFIGURED" : "AUTONOMOUS CORE"}
              </span>
            </div>

            {/* Tavily Status */}
            <div className="p-2 rounded bg-slate-950/80 border border-slate-800 flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-300">
                <Globe className="w-3.5 h-3.5 text-cyan-400" />
                Tavily Search
              </span>
              <span
                className={`px-1.5 py-0.5 rounded font-bold ${
                  systemStatus.searchStatus === "connected"
                    ? "bg-emerald-500/20 text-emerald-300"
                    : "bg-slate-800 text-slate-400"
                }`}
              >
                {systemStatus.searchStatus === "connected" ? "CONNECTED" : "NOT CONFIGURED"}
              </span>
            </div>
          </div>
        </div>

        {/* API Credentials Input */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <span className="font-bold text-cyan-300">API KEYS MANAGEMENT</span>
            <span className="text-[10px] text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400" /> Never exposed in public bundles
            </span>
          </div>

          {/* Gemini Key */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Google Gemini API Key:</span>
              <a
                href="https://aistudio.google.com/"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1 text-[10px]"
              >
                <span>Get Free Key</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </label>
            <input
              type="password"
              value={geminiKeyInput}
              onChange={(e) => setGeminiKeyInput(e.target.value)}
              placeholder="AIzaSy... (or set GEMINI_API_KEY in .env)"
              className="px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs text-slate-100 placeholder:text-slate-600 font-mono"
            />
          </div>

          {/* Model Selection */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-slate-400">Gemini Model Preference:</label>
            <select
              value={selectedModel}
              onChange={(e) => onSelectModel(e.target.value)}
              className="px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs text-slate-200 font-mono"
            >
              <option value="gemini-3.8-flash">gemini-3.8-flash (Recommended)</option>
              <option value="gemini-3.5-flash-lite">gemini-3.5-flash-lite (Lightweight)</option>
            </select>
          </div>

          {/* Tavily Search Key */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-slate-400 flex items-center justify-between">
              <span>Tavily Search API Key:</span>
              <a
                href="https://tavily.com/"
                target="_blank"
                rel="noreferrer"
                className="text-cyan-400 hover:underline flex items-center gap-1 text-[10px]"
              >
                <span>Get Free Key</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </a>
            </label>
            <input
              type="password"
              value={tavilyKeyInput}
              onChange={(e) => setTavilyKeyInput(e.target.value)}
              placeholder="tvly-... (or set TAVILY_API_KEY in .env)"
              className="px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs text-slate-100 placeholder:text-slate-600 font-mono"
            />
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSaveKeys}
              className="flex-1 py-2 px-3 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors"
            >
              Save Credentials
            </button>
            <button
              onClick={handleTestTavily}
              disabled={isTesting}
              className="py-2 px-3 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-cyan-300 font-bold transition-colors disabled:opacity-50"
            >
              {isTesting ? "Testing..." : "Test Web Search"}
            </button>
          </div>

          {saveSuccess && (
            <div className="p-2 rounded bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-[11px] flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>Credentials saved successfully to session configuration!</span>
            </div>
          )}

          {testResult && (
            <div className="p-2 rounded bg-cyan-950/40 border border-cyan-500/40 text-cyan-300 text-[11px]">
              {testResult}
            </div>
          )}
        </div>

        {/* Voice & Wake Word Options */}
        <div className="pt-3 border-t border-slate-800 flex flex-col gap-3">
          <span className="font-bold text-cyan-300 flex items-center gap-1.5">
            <Volume2 className="w-3.5 h-3.5 text-cyan-400" />
            VOICE SYNTHESIS & WAKE WORD
          </span>

          {/* Voice Selector */}
          <div className="flex flex-col gap-1">
            <label className="text-[11px] text-slate-400">Assistant Spoken Voice:</label>
            <select
              value={selectedVoice?.name || ""}
              onChange={(e) => {
                const v = availableVoices.find((voice) => voice.name === e.target.value);
                if (v) onSelectVoice(v);
              }}
              className="px-3 py-2 rounded-lg bg-slate-900 border border-slate-800 focus:border-cyan-500 text-xs text-slate-200 font-mono truncate"
            >
              {availableVoices.map((v) => (
                <option key={v.name} value={v.name}>
                  {v.name} ({v.lang})
                </option>
              ))}
            </select>
          </div>

          {/* Speech Speed & Pitch */}
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Speed:</span>
                <span className="text-cyan-400">{speechRate.toFixed(2)}x</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.5"
                step="0.05"
                value={speechRate}
                onChange={(e) => onChangeSpeechRate(parseFloat(e.target.value))}
                className="accent-cyan-400 cursor-pointer"
              />
            </div>

            <div className="flex flex-col gap-1">
              <div className="flex justify-between text-[11px] text-slate-400">
                <span>Pitch:</span>
                <span className="text-cyan-400">{speechPitch.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0.7"
                max="1.3"
                step="0.05"
                value={speechPitch}
                onChange={(e) => onChangeSpeechPitch(parseFloat(e.target.value))}
                className="accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>

          {/* Wake Word Detection */}
          <div className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex flex-col">
              <span className="text-[11px] text-slate-200 font-bold">Wake Word Filter</span>
              <span className="text-[10px] text-slate-400">Trigger only when saying "Jarvis" first</span>
            </div>
            <button
              onClick={() => onToggleWakeWord(!wakeWordEnabled)}
              className={`px-2.5 py-1 rounded font-bold text-[10px] border transition-colors ${
                wakeWordEnabled
                  ? "bg-cyan-500/20 border-cyan-500/40 text-cyan-300"
                  : "bg-slate-800 border-slate-700 text-slate-400"
              }`}
            >
              {wakeWordEnabled ? "ENABLED" : "DISABLED"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
