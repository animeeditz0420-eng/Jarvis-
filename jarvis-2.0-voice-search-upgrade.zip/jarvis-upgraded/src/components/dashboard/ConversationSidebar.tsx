"use client";

import React, { useState } from "react";
import { ConversationSession, NoteItem, ReminderItem } from "@/types/jarvis";
import { MessageSquare, FileText, CheckSquare, Trash2, X, Plus, Calendar, Check } from "lucide-react";

interface ConversationSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  sessions: ConversationSession[];
  activeSessionId?: string;
  onSelectSession: (id: string) => void;
  onNewSession: () => void;
  onDeleteSession: (id: string) => void;
  onClearAll: () => void;
  notes: NoteItem[];
  onDeleteNote: (id: number) => void;
  reminders: ReminderItem[];
  onToggleReminder: (id: number, completed: boolean) => void;
  onDeleteReminder: (id: number) => void;
}

export default function ConversationSidebar({
  isOpen,
  onClose,
  sessions,
  activeSessionId,
  onSelectSession,
  onNewSession,
  onDeleteSession,
  onClearAll,
  notes,
  onDeleteNote,
  reminders,
  onToggleReminder,
  onDeleteReminder,
}: ConversationSidebarProps) {
  const [activeTab, setActiveTab] = useState<"history" | "notes" | "reminders">("history");

  if (!isOpen) return null;

  return (
    <aside className="fixed inset-y-0 left-0 z-40 w-72 max-w-[85vw] bg-slate-950/95 backdrop-blur-xl border-r border-cyan-500/20 p-3.5 flex flex-col gap-3 font-mono text-xs select-none shadow-2xl animate-in slide-in-from-left duration-200">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-cyan-500/20">
        <span className="font-bold text-cyan-300 tracking-wider flex items-center gap-1.5">
          <MessageSquare className="w-4 h-4 text-cyan-400" />
          MEMORY & SESSIONS
        </span>
        <button
          onClick={onClose}
          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Tabs */}
      <div className="flex bg-slate-900/80 p-0.5 rounded border border-slate-800">
        <button
          onClick={() => setActiveTab("history")}
          className={`flex-1 py-1 rounded text-center transition-colors flex items-center justify-center gap-1 ${
            activeTab === "history" ? "bg-cyan-500/20 text-cyan-300 font-bold" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <MessageSquare className="w-3 h-3" />
          <span>Chats</span>
        </button>
        <button
          onClick={() => setActiveTab("notes")}
          className={`flex-1 py-1 rounded text-center transition-colors flex items-center justify-center gap-1 ${
            activeTab === "notes" ? "bg-cyan-500/20 text-cyan-300 font-bold" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <FileText className="w-3 h-3" />
          <span>Notes ({notes.length})</span>
        </button>
        <button
          onClick={() => setActiveTab("reminders")}
          className={`flex-1 py-1 rounded text-center transition-colors flex items-center justify-center gap-1 ${
            activeTab === "reminders" ? "bg-cyan-500/20 text-cyan-300 font-bold" : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <CheckSquare className="w-3 h-3" />
          <span>Tasks ({reminders.length})</span>
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
        {/* TAB 1: SESSIONS */}
        {activeTab === "history" && (
          <>
            <button
              onClick={() => {
                onNewSession();
                onClose();
              }}
              className="w-full py-2 px-2.5 rounded-md bg-cyan-950/40 hover:bg-cyan-900/40 border border-cyan-500/30 text-cyan-300 flex items-center justify-center gap-1.5 font-bold transition-colors mb-2"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>New Conversation</span>
            </button>

            {sessions.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-[11px]">
                No stored sessions yet. Start speaking or typing to begin!
              </div>
            ) : (
              sessions.map((sess) => {
                const isSelected = sess.id === activeSessionId;
                return (
                  <div
                    key={sess.id}
                    onClick={() => {
                      onSelectSession(sess.id);
                      onClose();
                    }}
                    className={`group p-2 rounded-md border cursor-pointer transition-all flex items-center justify-between gap-2 ${
                      isSelected
                        ? "bg-cyan-950/60 border-cyan-500/50 text-cyan-200"
                        : "bg-slate-900/40 border-slate-800 text-slate-300 hover:border-cyan-500/30 hover:bg-slate-900"
                    }`}
                  >
                    <div className="truncate flex-1">
                      <div className="font-semibold truncate text-[11px]">{sess.title}</div>
                      <div className="text-[10px] text-slate-500">
                        {new Date(sess.updatedAt).toLocaleDateString("en-IN", {
                          month: "short",
                          day: "numeric",
                        })}
                      </div>
                    </div>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteSession(sess.id);
                      }}
                      className="opacity-0 group-hover:opacity-100 p-1 rounded hover:bg-red-950/50 text-slate-500 hover:text-red-400 transition-opacity"
                      title="Delete Session"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })
            )}
          </>
        )}

        {/* TAB 2: NOTES */}
        {activeTab === "notes" && (
          <>
            {notes.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-[11px]">
                No notes saved. Say "Jarvis, take a note: buy quantum computing book" to save one!
              </div>
            ) : (
              notes.map((n) => (
                <div
                  key={n.id}
                  className="p-2.5 rounded bg-slate-900/60 border border-slate-800 flex flex-col gap-1"
                >
                  <div className="flex items-center justify-between font-bold text-cyan-300 text-[11px]">
                    <span className="truncate">{n.title}</span>
                    <button
                      onClick={() => onDeleteNote(n.id)}
                      className="p-1 text-slate-500 hover:text-red-400"
                      title="Delete Note"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                  <div className="text-slate-300 text-[11px] whitespace-pre-wrap">{n.content}</div>
                  <div className="text-[10px] text-slate-500 mt-1">
                    {new Date(n.createdAt).toLocaleString("en-IN", { dateStyle: "short", timeStyle: "short" })}
                  </div>
                </div>
              ))
            )}
          </>
        )}

        {/* TAB 3: REMINDERS */}
        {activeTab === "reminders" && (
          <>
            {reminders.length === 0 ? (
              <div className="text-center py-8 text-slate-500 text-[11px]">
                No reminders yet. Say "Jarvis, remind me to submit project at 5 PM" to create one!
              </div>
            ) : (
              reminders.map((r) => (
                <div
                  key={r.id}
                  className={`p-2.5 rounded border flex items-start justify-between gap-2 transition-colors ${
                    r.completed
                      ? "bg-slate-900/30 border-slate-800/60 text-slate-500 line-through"
                      : "bg-slate-900/60 border-cyan-500/20 text-slate-200"
                  }`}
                >
                  <button
                    onClick={() => onToggleReminder(r.id, !r.completed)}
                    className={`mt-0.5 p-0.5 rounded border ${
                      r.completed
                        ? "bg-cyan-500 border-cyan-400 text-slate-950"
                        : "border-slate-700 hover:border-cyan-400"
                    }`}
                  >
                    <Check className="w-3 h-3" />
                  </button>
                  <div className="flex-1 text-[11px]">
                    <div className="font-medium">{r.text}</div>
                    <div className="text-[10px] text-cyan-400/80 mt-0.5">Due: {r.dueTime}</div>
                  </div>
                  <button
                    onClick={() => onDeleteReminder(r.id)}
                    className="p-1 text-slate-500 hover:text-red-400"
                    title="Delete Reminder"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              ))
            )}
          </>
        )}
      </div>

      {/* Clear Memory Button */}
      <div className="pt-2 border-t border-slate-800">
        <button
          onClick={() => {
            if (window.confirm("Are you sure you want to clear all JARVIS memory & conversation history?")) {
              onClearAll();
            }
          }}
          className="w-full py-1.5 px-2 rounded bg-red-950/30 hover:bg-red-950/60 border border-red-500/30 text-red-300 flex items-center justify-center gap-1.5 transition-colors text-[11px]"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span>Clear All Memory</span>
        </button>
      </div>
    </aside>
  );
}
