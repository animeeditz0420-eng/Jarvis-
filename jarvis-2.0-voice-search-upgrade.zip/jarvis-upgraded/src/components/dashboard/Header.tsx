"use client";

import React, { useState, useEffect } from "react";
import {
  Cpu,
  Globe,
  Mic,
  Volume2,
  VolumeX,
  Settings,
  PlusCircle,
  Database,
  Radio,
  BookOpen,
  Code,
  Search,
  Sparkles,
  Sliders,
} from "lucide-react";
import { JarvisMode, QualityMode, SystemStatusData } from "@/types/jarvis";

interface HeaderProps {
  mode: JarvisMode;
  onModeChange: (mode: JarvisMode) => void;
  quality: QualityMode;
  onQualityChange: (quality: QualityMode) => void;
  systemStatus: SystemStatusData;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenSettings: () => void;
  onNewSession: () => void;
  onToggleSidebar: () => void;
}

export default function Header({
  mode,
  onModeChange,
  quality,
  onQualityChange,
  systemStatus,
  isMuted,
  onToggleMute,
  onOpenSettings,
  onNewSession,
  onToggleSidebar,
}: HeaderProps) {
  const [currentTime, setCurrentTime] = useState<string>("");

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString("en-IN", {
          hour: "2-digit",
          minute: "2-digit",
          second: "2-digit",
          hour12: true,
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const modes: Array<{ id: JarvisMode; label: string; icon: React.ReactNode }> = [
    { id: "assistant", label: "Assistant", icon: <Sparkles className="w-3.5 h-3.5" /> },
    { id: "search", label: "Live Search", icon: <Search className="w-3.5 h-3.5" /> },
    { id: "study", label: "Study Mode", icon: <BookOpen className="w-3.5 h-3.5" /> },
    { id: "developer", label: "Developer", icon: <Code className="w-3.5 h-3.5" /> },
  ];

  return (
    <header className="relative z-30 w-full px-4 py-2.5 bg-slate-950/80 backdrop-blur-md border-b border-cyan-500/20 flex flex-wrap items-center justify-between gap-3 text-xs select-none">
      {/* Brand & Status */}
      <div className="flex items-center gap-3">
        <button
          onClick={onToggleSidebar}
          className="px-2.5 py-1.5 rounded-md bg-cyan-950/50 hover:bg-cyan-900/50 border border-cyan-500/30 text-cyan-300 font-mono tracking-wider transition-colors flex items-center gap-2"
          title="Toggle Memory & Session History"
        >
          <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
          <span className="font-bold tracking-widest text-cyan-200">JARVIS 2.0</span>
        </button>

        {/* Real System Telemetry Badges */}
        <div className="hidden sm:flex items-center gap-2 font-mono">
          <div
            className={`px-2 py-0.5 rounded border flex items-center gap-1.5 ${
              systemStatus.aiStatus === "connected"
                ? "bg-emerald-950/50 border-emerald-500/40 text-emerald-300"
                : "bg-cyan-950/40 border-cyan-500/30 text-cyan-300"
            }`}
            title={`AI Engine: ${systemStatus.aiModel} (${systemStatus.aiStatus})`}
          >
            <Cpu className="w-3 h-3" />
            <span>AI: {systemStatus.aiStatus === "connected" ? "LIVE" : "CORE"}</span>
          </div>

          <div
            className={`px-2 py-0.5 rounded border flex items-center gap-1.5 ${
              systemStatus.searchStatus === "connected"
                ? "bg-cyan-950/60 border-cyan-500/50 text-cyan-300"
                : "bg-slate-900/60 border-slate-700/50 text-slate-400"
            }`}
            title={`Tavily Search: ${systemStatus.searchStatus}`}
          >
            <Globe className="w-3 h-3" />
            <span>WEB: {systemStatus.searchStatus === "connected" ? "TAVILY" : "OFFLINE"}</span>
          </div>

          <div
            className="px-2 py-0.5 rounded border bg-slate-900/40 border-slate-800 text-slate-400 flex items-center gap-1.5"
            title="PostgreSQL Database Connection"
          >
            <Database className="w-3 h-3 text-cyan-400" />
            <span>DB: {systemStatus.databaseStatus === "connected" ? "SYNCED" : "RETRY"}</span>
          </div>

          <div className="px-2 py-0.5 rounded border bg-cyan-950/30 border-cyan-900 text-cyan-400/90 font-mono">
            {currentTime}
          </div>
        </div>
      </div>

      {/* Mode Selector Tabs */}
      <div className="flex items-center bg-slate-900/80 p-0.5 rounded-lg border border-cyan-500/20">
        {modes.map((m) => {
          const isActive = mode === m.id;
          return (
            <button
              key={m.id}
              onClick={() => onModeChange(m.id)}
              className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1.5 ${
                isActive
                  ? "bg-cyan-500 text-slate-950 font-semibold shadow-[0_0_12px_rgba(0,242,254,0.5)]"
                  : "text-slate-400 hover:text-cyan-300 hover:bg-cyan-950/30"
              }`}
            >
              {m.icon}
              <span className="hidden md:inline">{m.label}</span>
            </button>
          );
        })}
      </div>

      {/* Action Controls */}
      <div className="flex items-center gap-2">
        {/* Quality Mode Dropdown */}
        <div className="hidden lg:flex items-center gap-1 bg-slate-900/60 border border-slate-800 rounded px-1.5 py-0.5 text-slate-300 font-mono text-[10px]">
          <span className="text-slate-500">RES:</span>
          {(["performance", "balanced", "high"] as QualityMode[]).map((q) => (
            <button
              key={q}
              onClick={() => onQualityChange(q)}
              className={`px-1.5 py-0.5 rounded capitalize ${
                quality === q ? "bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40" : "hover:text-cyan-400"
              }`}
            >
              {q === "performance" ? "Perf" : q === "balanced" ? "Bal" : "High"}
            </button>
          ))}
        </div>

        {/* Audio Mute */}
        <button
          onClick={onToggleMute}
          className={`p-1.5 rounded-md border transition-colors ${
            isMuted
              ? "bg-amber-950/40 border-amber-500/40 text-amber-400"
              : "bg-slate-900/60 border-slate-800 text-cyan-300 hover:bg-cyan-950/40"
          }`}
          title={isMuted ? "Unmute Voice" : "Mute Voice"}
        >
          {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* New Session */}
        <button
          onClick={onNewSession}
          className="p-1.5 rounded-md bg-slate-900/60 hover:bg-cyan-950/40 border border-slate-800 text-cyan-300 transition-colors"
          title="Start Fresh Conversation"
        >
          <PlusCircle className="w-4 h-4" />
        </button>

        {/* Settings / API Key Config */}
        <button
          onClick={onOpenSettings}
          className="p-1.5 rounded-md bg-cyan-950/50 hover:bg-cyan-900/50 border border-cyan-500/40 text-cyan-300 transition-colors flex items-center gap-1"
          title="Configure API Keys & Voice Settings"
        >
          <Settings className="w-4 h-4" />
          <span className="hidden xl:inline text-[11px] font-mono">CONFIG</span>
        </button>
      </div>
    </header>
  );
}
