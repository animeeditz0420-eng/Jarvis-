"use client";

import React, { useEffect, useRef, useState } from "react";
import { HologramState, ToolCallData, NoteItem, ReminderItem } from "@/types/jarvis";
import { audioAnalyzer } from "@/services/audio/audioAnalyzer";
import { Activity, Clock, Calculator, CheckSquare, FileText, ExternalLink, Zap } from "lucide-react";

interface SystemDiagnosticsProps {
  hologramState: HologramState;
  activeTool?: ToolCallData;
  activeTimer?: { secondsLeft: number; totalSeconds: number; label: string } | null;
  onClearTimer?: () => void;
  isOpen?: boolean;
}

export default function SystemDiagnostics({
  hologramState,
  activeTool,
  activeTimer,
  onClearTimer,
  isOpen = true,
}: SystemDiagnosticsProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [telemetry, setTelemetry] = useState({ amp: 0, bass: 0, mid: 0, treble: 0 });

  // Real-time canvas spectrum visualizer loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const render = () => {
      animId = requestAnimationFrame(render);
      const data = audioAnalyzer.getAnalysis();

      setTelemetry({
        amp: Math.round(data.amplitude * 100),
        bass: Math.round(data.bass * 100),
        mid: Math.round(data.mid * 100),
        treble: Math.round(data.treble * 100),
      });

      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      const barCount = 24;
      const barWidth = width / barCount - 2;

      for (let i = 0; i < barCount; i++) {
        const binIdx = Math.floor((i / barCount) * (data.frequencyData.length * 0.7));
        const val = data.frequencyData[binIdx] || 0;
        const barHeight = Math.max(2, (val / 255) * height);

        // Color gradient based on state
        if (hologramState === "error") {
          ctx.fillStyle = `rgba(239, 68, 68, ${0.4 + (val / 255) * 0.6})`;
        } else if (hologramState === "searching") {
          ctx.fillStyle = `rgba(6, 182, 212, ${0.4 + (val / 255) * 0.6})`;
        } else {
          ctx.fillStyle = `rgba(0, 242, 254, ${0.4 + (val / 255) * 0.6})`;
        }

        ctx.fillRect(i * (barWidth + 2), height - barHeight, barWidth, barHeight);
      }
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [hologramState]);

  if (!isOpen) return null;

  return (
    <aside className="w-64 max-w-full bg-slate-950/70 backdrop-blur-md border-l border-cyan-500/20 p-3 flex flex-col gap-3 font-mono text-xs select-none overflow-y-auto">
      {/* State & Core Status */}
      <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 flex flex-col gap-2">
        <div className="flex items-center justify-between text-[11px] text-slate-400">
          <span className="flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            HOLOGRAM CORE
          </span>
          <span
            className={`px-1.5 py-0.5 rounded font-bold uppercase text-[10px] ${
              hologramState === "error"
                ? "bg-red-500/20 text-red-400 border border-red-500/30"
                : hologramState === "listening"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 animate-pulse"
                : hologramState === "thinking"
                ? "bg-sky-500/20 text-sky-300 border border-sky-500/40 animate-pulse"
                : hologramState === "speaking"
                ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                : hologramState === "searching"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                : "bg-slate-800 text-slate-300"
            }`}
          >
            {hologramState}
          </span>
        </div>

        {/* Live Audio Spectrum */}
        <div className="flex flex-col gap-1">
          <div className="flex justify-between text-[10px] text-slate-500">
            <span>AUDIO SPECTRUM</span>
            <span className="text-cyan-400">{telemetry.amp}% AMP</span>
          </div>
          <canvas ref={canvasRef} width={220} height={36} className="w-full h-9 rounded bg-slate-950/80 border border-cyan-500/10" />
        </div>

        {/* Frequency telemetry breakdown */}
        <div className="grid grid-cols-3 gap-1 text-[10px] text-center pt-1 border-t border-slate-800">
          <div>
            <span className="text-slate-500 block">BASS</span>
            <span className="text-cyan-300">{telemetry.bass}%</span>
          </div>
          <div>
            <span className="text-slate-500 block">MID</span>
            <span className="text-cyan-300">{telemetry.mid}%</span>
          </div>
          <div>
            <span className="text-slate-500 block">HIGH</span>
            <span className="text-cyan-300">{telemetry.treble}%</span>
          </div>
        </div>
      </div>

      {/* Active Timer Countdown Widget */}
      {activeTimer && activeTimer.secondsLeft > 0 && (
        <div className="p-2.5 rounded-lg bg-cyan-950/40 border border-cyan-500/40 flex flex-col gap-1.5 animate-pulse">
          <div className="flex items-center justify-between text-cyan-300">
            <span className="flex items-center gap-1.5 font-bold">
              <Clock className="w-3.5 h-3.5 text-cyan-400" />
              ACTIVE TIMER
            </span>
            <button
              onClick={onClearTimer}
              className="text-[10px] text-slate-400 hover:text-red-400"
              title="Cancel Timer"
            >
              STOP
            </button>
          </div>
          <div className="text-xl font-bold text-center text-cyan-200 tracking-widest">
            {Math.floor(activeTimer.secondsLeft / 60)
              .toString()
              .padStart(2, "0")}
            :{(activeTimer.secondsLeft % 60).toString().padStart(2, "0")}
          </div>
          <div className="text-[10px] text-slate-400 truncate text-center">
            {activeTimer.label || "Timer Alert"}
          </div>
        </div>
      )}

      {/* Recent / Active Tool Feedback */}
      {activeTool && (
        <div className="p-2.5 rounded-lg bg-slate-900/60 border border-cyan-500/20 flex flex-col gap-1.5">
          <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-[11px]">
            {activeTool.toolName === "calculator" && <Calculator className="w-3.5 h-3.5" />}
            {activeTool.toolName === "datetime" && <Clock className="w-3.5 h-3.5" />}
            {activeTool.toolName === "notes" && <FileText className="w-3.5 h-3.5" />}
            {activeTool.toolName === "reminder" && <CheckSquare className="w-3.5 h-3.5" />}
            {activeTool.toolName === "website_opener" && <ExternalLink className="w-3.5 h-3.5" />}
            <span className="uppercase">TOOL: {activeTool.toolName}</span>
          </div>

          <div className="text-[11px] text-slate-300 font-mono bg-slate-950/70 p-2 rounded border border-slate-800">
            {activeTool.toolName === "calculator" && (
              <div>
                <div className="text-slate-500">{activeTool.input?.expression} =</div>
                <div className="text-cyan-300 font-bold text-sm">{activeTool.output?.result}</div>
              </div>
            )}
            {activeTool.toolName === "datetime" && (
              <div>
                <div className="text-cyan-300">{activeTool.output?.localFormatted}</div>
              </div>
            )}
            {activeTool.toolName === "notes" && (
              <div className="text-emerald-300">Note saved to database successfully.</div>
            )}
            {activeTool.toolName === "reminder" && (
              <div className="text-cyan-300">
                Reminder set: "{activeTool.input?.text}" at {activeTool.input?.dueTime}.
              </div>
            )}
            {activeTool.toolName === "website_opener" && (
              <div className="text-amber-300">
                Awaiting your confirmation to open {activeTool.output?.siteName}.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Quick Tips / Instructions */}
      <div className="mt-auto p-2 rounded bg-slate-900/40 border border-slate-800/60 text-[10px] text-slate-400 flex flex-col gap-1">
        <span className="text-cyan-400/90 font-bold flex items-center gap-1">
          <Zap className="w-3 h-3" /> VOICE COMMANDS
        </span>
        <p>• "Jarvis, aaj internet par AI ki latest news search karo"</p>
        <p>• "Jarvis, explain quantum physics in simple Hindi"</p>
        <p>• "Calculate 450 * 18.5"</p>
        <p>• "Set a timer for 3 minutes"</p>
      </div>
    </aside>
  );
}
