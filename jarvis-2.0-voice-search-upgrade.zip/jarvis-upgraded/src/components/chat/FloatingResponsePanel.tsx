"use client";

import React, { useState } from "react";
import { ChatMessage, SourceCitation, ToolCallData } from "@/types/jarvis";
import {
  Volume2,
  VolumeX,
  Copy,
  Check,
  ExternalLink,
  Search,
  Globe,
  Calculator,
  Clock,
  Sparkles,
  AlertTriangle,
} from "lucide-react";

interface FloatingResponsePanelProps {
  lastUserMessage?: string;
  lastAssistantMessage?: ChatMessage | null;
  interimTranscript?: string;
  isListening?: boolean;
  isThinking?: boolean;
  isSpeaking?: boolean;
  onSpeakText?: (text: string) => void;
  onStopSpeaking?: () => void;
  onConfirmWebsiteOpen?: (url: string) => void;
}

export default function FloatingResponsePanel({
  lastUserMessage,
  lastAssistantMessage,
  interimTranscript,
  isListening,
  isThinking,
  isSpeaking,
  onSpeakText,
  onStopSpeaking,
  onConfirmWebsiteOpen,
}: FloatingResponsePanelProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const hasContent = Boolean(
    lastUserMessage || lastAssistantMessage || interimTranscript || isListening || isThinking
  );

  if (!hasContent) return null;

  return (
    <div className="absolute top-16 inset-x-4 sm:inset-x-auto sm:left-1/2 sm:-translate-x-1/2 sm:w-[620px] max-w-full z-20 flex flex-col gap-2 pointer-events-none">
      {/* Live User Recognized Speech / Interim Feedback */}
      {(isListening || interimTranscript || lastUserMessage) && (
        <div className="p-3 rounded-xl bg-slate-950/80 backdrop-blur-md border border-cyan-500/30 text-xs text-cyan-200 shadow-lg pointer-events-auto flex items-center justify-between gap-3 animate-in fade-in duration-200">
          <div className="flex items-center gap-2 flex-1 truncate">
            <span
              className={`w-2 h-2 rounded-full ${
                isListening ? "bg-cyan-400 animate-ping" : "bg-slate-500"
              }`}
            />
            <span className="font-mono text-slate-400 text-[11px]">YOU:</span>
            <span className="font-medium text-slate-100 truncate">
              {interimTranscript ? (
                <span className="italic text-cyan-300">{interimTranscript}</span>
              ) : (
                lastUserMessage || "Listening for your voice..."
              )}
            </span>
          </div>

          {isListening && (
            <span className="font-mono text-[10px] text-cyan-400 animate-pulse uppercase tracking-wider">
              [MIC ACTIVE]
            </span>
          )}
        </div>
      )}

      {/* Thinking Indicator */}
      {isThinking && (
        <div className="p-3 rounded-xl bg-slate-950/85 backdrop-blur-md border border-sky-500/40 text-xs text-sky-200 shadow-xl pointer-events-auto flex items-center gap-3 animate-pulse">
          <div className="w-4 h-4 rounded-full border-2 border-sky-400 border-t-transparent animate-spin" />
          <span className="font-mono tracking-wider">
            JARVIS is synthesizing intelligence & analyzing tool parameters...
          </span>
        </div>
      )}

      {/* Spoken Response Panel */}
      {lastAssistantMessage && !isThinking && (
        <div className="p-4 rounded-2xl bg-slate-950/90 backdrop-blur-xl border border-cyan-500/40 text-slate-100 shadow-[0_0_30px_rgba(0,242,254,0.15)] pointer-events-auto flex flex-col gap-3 animate-in fade-in slide-in-from-top-2 duration-300 max-h-[60vh] overflow-y-auto">
          {/* Top Bar */}
          <div className="flex items-center justify-between border-b border-cyan-500/20 pb-2 text-[11px] font-mono text-cyan-400">
            <div className="flex items-center gap-2">
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span className="font-bold tracking-widest text-cyan-200">JARVIS RESPONSE</span>
              {isSpeaking && (
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] animate-pulse">
                  SPEAKING
                </span>
              )}
            </div>

            <div className="flex items-center gap-1.5">
              {isSpeaking ? (
                <button
                  onClick={onStopSpeaking}
                  className="px-2 py-0.5 rounded bg-amber-950/40 border border-amber-500/40 text-amber-300 hover:bg-amber-900/40 flex items-center gap-1 transition-colors"
                  title="Interrupt Assistant Speech"
                >
                  <VolumeX className="w-3 h-3" />
                  <span>STOP</span>
                </button>
              ) : (
                <button
                  onClick={() => onSpeakText && onSpeakText(lastAssistantMessage.content)}
                  className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 transition-colors"
                  title="Replay Voice"
                >
                  <Volume2 className="w-3.5 h-3.5" />
                </button>
              )}

              <button
                onClick={() => handleCopy(lastAssistantMessage.content)}
                className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 transition-colors"
                title="Copy Text"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {/* Response Text */}
          <div className="text-xs sm:text-sm leading-relaxed text-slate-200 font-sans whitespace-pre-wrap selection:bg-cyan-500 selection:text-slate-950">
            {lastAssistantMessage.content}
          </div>

          {/* Tool Execution Confirmation (e.g. Website Opener) */}
          {lastAssistantMessage.toolData &&
            lastAssistantMessage.toolData.toolName === "website_opener" &&
            lastAssistantMessage.toolData.output?.url && (
              <div className="p-3 rounded-xl bg-amber-950/30 border border-amber-500/40 text-xs flex flex-col gap-2">
                <div className="flex items-center gap-2 text-amber-300 font-bold">
                  <AlertTriangle className="w-4 h-4" />
                  <span>EXTERNAL NAVIGATION PERMISSION</span>
                </div>
                <p className="text-slate-300 text-[11px]">
                  JARVIS has prepared to open{" "}
                  <strong className="text-cyan-300">{lastAssistantMessage.toolData.output.siteName}</strong> (
                  {lastAssistantMessage.toolData.output.url}). Do you wish to proceed?
                </p>
                <div className="flex gap-2">
                  <a
                    href={lastAssistantMessage.toolData.output.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-md bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 transition-colors inline-flex items-center gap-1.5"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Proceed to Website</span>
                  </a>
                </div>
              </div>
            )}

          {/* Search Citations & Clickable Sources */}
          {lastAssistantMessage.sources && lastAssistantMessage.sources.length > 0 && (
            <div className="pt-2 border-t border-cyan-500/20 flex flex-col gap-1.5">
              <span className="text-[10px] font-mono text-cyan-400 flex items-center gap-1">
                <Globe className="w-3 h-3" /> VERIFIED WEB SOURCES ({lastAssistantMessage.sources.length}):
              </span>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                {lastAssistantMessage.sources.map((src, i) => (
                  <a
                    key={i}
                    href={src.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded-lg bg-slate-900/80 hover:bg-cyan-950/50 border border-slate-800 hover:border-cyan-500/40 transition-colors text-[11px] flex items-start gap-1.5 group"
                  >
                    <ExternalLink className="w-3 h-3 text-cyan-400 mt-0.5 shrink-0 group-hover:translate-x-0.5 transition-transform" />
                    <div className="truncate flex-1">
                      <div className="text-cyan-200 font-medium truncate group-hover:text-cyan-100">
                        {src.title}
                      </div>
                      <div className="text-[9px] text-slate-400 flex items-center gap-1">
                        <span className="truncate">{new URL(src.url).hostname}</span>
                        {src.publishedDate && <span>• {src.publishedDate}</span>}
                      </div>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
