"use client";

import React, { useEffect, useRef } from "react";
import * as THREE from "three";
import { HologramState, QualityMode } from "@/types/jarvis";
import { audioAnalyzer } from "@/services/audio/audioAnalyzer";

interface GeometricHologramProps {
  state: HologramState;
  quality?: QualityMode;
  onTap?: () => void;
  className?: string;
}

export default function GeometricHologram({
  state,
  quality = "balanced",
  onTap,
  className = "",
}: GeometricHologramProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const stateRef = useRef<HologramState>(state);
  const qualityRef = useRef<QualityMode>(quality);

  // Keep stateRef and qualityRef updated without restarting Three.js scene
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    qualityRef.current = quality;
  }, [quality]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // --- 1. Scene, Camera, Renderer Setup ---
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x020617, 0.08);

    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      100
    );
    camera.position.set(0, 0, 8.5);

    const renderer = new THREE.WebGLRenderer({
      antialias: qualityRef.current !== "performance",
      alpha: true,
      powerPreference: "high-performance",
    });

    const maxDpr = qualityRef.current === "high" ? 2 : qualityRef.current === "balanced" ? 1.5 : 1.0;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, maxDpr));
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.25;

    container.appendChild(renderer.domElement);

    // --- 2. Color Palettes ---
    const colors = {
      cyan: new THREE.Color(0x00f2fe),
      deepBlue: new THREE.Color(0x001b3a),
      electricBlue: new THREE.Color(0x0284c7),
      iceWhite: new THREE.Color(0xe0f2fe),
      errorRed: new THREE.Color(0xef4444),
      searchAmber: new THREE.Color(0x06b6d4),
      thinkingViolet: new THREE.Color(0x38bdf8),
    };

    let currentColor = colors.cyan.clone();
    let targetColor = colors.cyan.clone();

    // --- 3. Geometric Components Hierarchy ---
    const rootGroup = new THREE.Group();
    scene.add(rootGroup);

    // A. CENTRAL SINGULARITY CORE
    const coreGeo = new THREE.DodecahedronGeometry(0.55, 1);
    const coreMat = new THREE.MeshBasicMaterial({
      color: colors.cyan,
      wireframe: true,
      transparent: true,
      opacity: 0.85,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    rootGroup.add(coreMesh);

    // Central Point Light for volumetric glow feel
    const coreLight = new THREE.PointLight(0x00ffff, 3.5, 12, 1.8);
    rootGroup.add(coreLight);

    // B. INNER COMPLEX STELLATED WIREFRAME (Central Lattice)
    const innerGeo = new THREE.IcosahedronGeometry(1.4, 1);
    const innerWireMat = new THREE.MeshBasicMaterial({
      color: colors.cyan,
      wireframe: true,
      transparent: true,
      opacity: 0.65,
    });
    const innerMesh = new THREE.Mesh(innerGeo, innerWireMat);
    rootGroup.add(innerMesh);

    // C. FACETED HOLOGRAPHIC TRANSPARENT SHELL (Irregular Interconnected Polygonal Surfaces)
    const shellGeo = new THREE.IcosahedronGeometry(1.85, 1);
    const shellMat = new THREE.MeshStandardMaterial({
      color: colors.deepBlue,
      roughness: 0.15,
      metalness: 0.85,
      transparent: true,
      opacity: 0.28,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
      wireframe: false,
    });
    const shellMesh = new THREE.Mesh(shellGeo, shellMat);
    rootGroup.add(shellMesh);

    // Wireframe overlay for shell edges
    const shellWireMat = new THREE.MeshBasicMaterial({
      color: colors.cyan,
      wireframe: true,
      transparent: true,
      opacity: 0.45,
    });
    const shellWireMesh = new THREE.Mesh(shellGeo, shellWireMat);
    rootGroup.add(shellWireMesh);

    // D. DUAL INVERTED OCTAHEDRAL CAGE
    const cageGeo = new THREE.OctahedronGeometry(2.2, 1);
    const cageMat = new THREE.MeshBasicMaterial({
      color: colors.electricBlue,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
    });
    const cageMesh = new THREE.Mesh(cageGeo, cageMat);
    rootGroup.add(cageMesh);

    // E. ROTATING GYROSCOPIC ORBITAL GIMBAL RINGS
    const orbitalGroup = new THREE.Group();
    rootGroup.add(orbitalGroup);

    const ringMat1 = new THREE.LineBasicMaterial({
      color: colors.cyan,
      transparent: true,
      opacity: 0.55,
    });
    const ringMat2 = new THREE.LineBasicMaterial({
      color: colors.electricBlue,
      transparent: true,
      opacity: 0.4,
    });
    const ringMat3 = new THREE.LineBasicMaterial({
      color: colors.iceWhite,
      transparent: true,
      opacity: 0.5,
    });

    // Create segmented orbital rings
    const createSegmentedRing = (radius: number, segments: number) => {
      const points: THREE.Vector3[] = [];
      for (let i = 0; i <= segments; i++) {
        const theta = (i / segments) * Math.PI * 2;
        points.push(new THREE.Vector3(Math.cos(theta) * radius, Math.sin(theta) * radius, 0));
      }
      const geo = new THREE.BufferGeometry().setFromPoints(points);
      return new THREE.LineLoop(geo);
    };

    const ring1 = createSegmentedRing(2.8, 64);
    const ring2 = createSegmentedRing(3.35, 64);
    const ring3 = createSegmentedRing(3.9, 80);

    ring1.rotation.x = Math.PI / 4;
    ring2.rotation.y = Math.PI / 3;
    ring3.rotation.z = Math.PI / 6;

    orbitalGroup.add(ring1);
    orbitalGroup.add(ring2);
    orbitalGroup.add(ring3);

    // F. FLOATING GEOMETRIC FRAGMENTS (Orbiting Shards)
    const fragmentCount = qualityRef.current === "performance" ? 14 : qualityRef.current === "balanced" ? 22 : 30;
    const fragmentGroup = new THREE.Group();
    rootGroup.add(fragmentGroup);

    const fragmentMeshes: Array<{
      mesh: THREE.Mesh;
      baseRadius: number;
      speed: number;
      orbitSpeed: number;
      axis: THREE.Vector3;
      phase: number;
      scaleFactor: number;
    }> = [];

    const fragmentGeometries = [
      new THREE.TetrahedronGeometry(0.2, 0),
      new THREE.OctahedronGeometry(0.24, 0),
      new THREE.IcosahedronGeometry(0.22, 0),
      new THREE.ConeGeometry(0.18, 0.35, 4),
    ];

    const fragMat = new THREE.MeshStandardMaterial({
      color: colors.cyan,
      roughness: 0.2,
      metalness: 0.9,
      transparent: true,
      opacity: 0.55,
      blending: THREE.AdditiveBlending,
      wireframe: true,
    });

    for (let i = 0; i < fragmentCount; i++) {
      const geo = fragmentGeometries[i % fragmentGeometries.length];
      const mesh = new THREE.Mesh(geo, fragMat);

      const baseRadius = 2.4 + Math.random() * 1.8;
      const u = Math.random();
      const v = Math.random();
      const theta = u * 2.0 * Math.PI;
      const phi = Math.acos(2.0 * v - 1.0);
      const r = Math.cbrt(Math.random()) * 0.4 + baseRadius;
      const sinPhi = Math.sin(phi);

      mesh.position.set(
        r * sinPhi * Math.cos(theta),
        r * sinPhi * Math.sin(theta),
        r * Math.cos(phi)
      );

      const axis = new THREE.Vector3(
        Math.random() - 0.5,
        Math.random() - 0.5,
        Math.random() - 0.5
      ).normalize();

      fragmentGroup.add(mesh);
      fragmentMeshes.push({
        mesh,
        baseRadius,
        speed: 0.5 + Math.random() * 1.2,
        orbitSpeed: (0.15 + Math.random() * 0.35) * (Math.random() > 0.5 ? 1 : -1),
        axis,
        phase: Math.random() * Math.PI * 2,
        scaleFactor: 0.7 + Math.random() * 0.6,
      });
    }

    // G. DYNAMIC CONNECTING ENERGY LINES (Tendrils between Core & Fragments)
    const maxLineSegments = 16;
    const linePositions = new Float32Array(maxLineSegments * 2 * 3);
    const lineGeometry = new THREE.BufferGeometry();
    lineGeometry.setAttribute("position", new THREE.BufferAttribute(linePositions, 3));

    const lineMaterial = new THREE.LineBasicMaterial({
      color: colors.cyan,
      transparent: true,
      opacity: 0.45,
      blending: THREE.AdditiveBlending,
    });
    const energyLines = new THREE.LineSegments(lineGeometry, lineMaterial);
    rootGroup.add(energyLines);

    // H. LUMINOUS SWIRLING PARTICLE CLOUD
    const particleCount = qualityRef.current === "performance" ? 400 : qualityRef.current === "balanced" ? 800 : 1300;
    const particleGeo = new THREE.BufferGeometry();
    const particlePositions = new Float32Array(particleCount * 3);
    const particleBaseData: Array<{ radius: number; theta: number; phi: number; speed: number }> = [];

    for (let i = 0; i < particleCount; i++) {
      const r = 1.2 + Math.random() * 3.6;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      particlePositions[i * 3] = r * Math.sin(phi) * Math.cos(theta);
      particlePositions[i * 3 + 1] = r * Math.sin(phi) * Math.sin(theta);
      particlePositions[i * 3 + 2] = r * Math.cos(phi);

      particleBaseData.push({
        radius: r,
        theta,
        phi,
        speed: (0.2 + Math.random() * 0.5) * (Math.random() > 0.5 ? 1 : -1),
      });
    }

    particleGeo.setAttribute("position", new THREE.BufferAttribute(particlePositions, 3));

    // Particle texture (procedural soft radial circle)
    const canvas = document.createElement("canvas");
    canvas.width = 32;
    canvas.height = 32;
    const ctx = canvas.getContext("2d");
    if (ctx) {
      const gradient = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
      gradient.addColorStop(0, "rgba(255,255,255,1)");
      gradient.addColorStop(0.3, "rgba(0,242,254,0.8)");
      gradient.addColorStop(1, "rgba(0,27,58,0)");
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, 32, 32);
    }
    const particleTexture = new THREE.CanvasTexture(canvas);

    const particleMat = new THREE.PointsMaterial({
      color: colors.cyan,
      size: 0.12,
      map: particleTexture,
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const particleSystem = new THREE.Points(particleGeo, particleMat);
    rootGroup.add(particleSystem);

    // I. HORIZONTAL SCANNING ENERGY WAVE (for Thinking & Searching states)
    const scanRingGeo = new THREE.RingGeometry(0.1, 4.2, 48);
    const scanRingMat = new THREE.MeshBasicMaterial({
      color: colors.cyan,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0,
      blending: THREE.AdditiveBlending,
    });
    const scanRing = new THREE.Mesh(scanRingGeo, scanRingMat);
    scanRing.rotation.x = Math.PI / 2;
    rootGroup.add(scanRing);

    // --- 4. Animation Variables & Smooth Dampening ---
    let time = 0;
    let scanWave = 0;
    let smoothAmplitude = 0;
    let smoothBass = 0;
    let smoothMid = 0;
    let smoothTreble = 0;

    let targetScale = 1.0;
    let currentScale = 1.0;
    let targetSpeed = 1.0;
    let currentSpeed = 1.0;
    let targetDistortion = 0;
    let currentDistortion = 0;

    // --- 5. Main Animation Loop ---
    let animationFrameId: number;

    const animate = () => {
      animationFrameId = requestAnimationFrame(animate);

      const delta = 0.016; // approximate 60fps delta
      time += delta * currentSpeed;

      const currentState = stateRef.current;

      // Real Audio Reactivity Extraction from Web Audio AnalyserNode
      const audio = audioAnalyzer.getAnalysis();
      const rawAmp = audio.amplitude;
      const rawBass = audio.bass;
      const rawMid = audio.mid;
      const rawTreble = audio.treble;

      // Smooth dampening for audio features
      smoothAmplitude += (rawAmp - smoothAmplitude) * 0.25;
      smoothBass += (rawBass - smoothBass) * 0.22;
      smoothMid += (rawMid - smoothMid) * 0.22;
      smoothTreble += (rawTreble - smoothTreble) * 0.22;

      // State-specific Target Parameter Adjustments
      switch (currentState) {
        case "idle":
          targetColor.copy(colors.cyan);
          targetScale = 1.0 + Math.sin(time * 1.5) * 0.05;
          targetSpeed = 0.8;
          targetDistortion = 0.02;
          scanRingMat.opacity = 0;
          break;

        case "listening":
          // Expands dynamically with mic intensity
          targetColor.copy(colors.electricBlue);
          targetScale = 1.15 + smoothAmplitude * 0.75;
          targetSpeed = 1.2 + smoothAmplitude * 1.5;
          targetDistortion = 0.05 + smoothAmplitude * 0.3;
          scanRingMat.opacity = 0.15 + smoothAmplitude * 0.4;
          break;

        case "thinking":
          targetColor.copy(colors.thinkingViolet);
          targetScale = 1.05 + Math.sin(time * 4.0) * 0.08;
          targetSpeed = 2.4;
          targetDistortion = 0.12;
          // Pulse scanning ring
          scanWave = (scanWave + delta * 2.2) % 1.0;
          scanRing.scale.set(scanWave * 1.2 + 0.1, scanWave * 1.2 + 0.1, 1);
          scanRingMat.opacity = (1 - scanWave) * 0.6;
          break;

        case "speaking":
          // Strongly reacts to assistant voice frequency spectrum
          targetColor.copy(colors.cyan);
          targetScale = 1.08 + smoothAmplitude * 0.85 + smoothBass * 0.4;
          targetSpeed = 1.4 + smoothMid * 2.0;
          targetDistortion = 0.08 + smoothTreble * 0.4;
          scanRingMat.opacity = smoothAmplitude * 0.4;
          break;

        case "searching":
          targetColor.copy(colors.searchAmber);
          targetScale = 1.1 + Math.sin(time * 3.0) * 0.1;
          targetSpeed = 3.0;
          targetDistortion = 0.15;
          scanWave = (scanWave + delta * 3.0) % 1.0;
          scanRing.scale.set(scanWave * 1.4 + 0.1, scanWave * 1.4 + 0.1, 1);
          scanRingMat.opacity = (1 - scanWave) * 0.75;
          break;

        case "error":
          targetColor.copy(colors.errorRed);
          targetScale = 1.0 + (Math.random() - 0.5) * 0.1;
          targetSpeed = 1.8;
          targetDistortion = 0.35;
          scanRingMat.opacity = 0.35;
          break;
      }

      // Smooth color interpolation
      currentColor.lerp(targetColor, 0.08);
      coreMat.color.copy(currentColor);
      innerWireMat.color.copy(currentColor);
      shellWireMat.color.copy(currentColor);
      cageMat.color.copy(currentColor);
      ringMat1.color.copy(currentColor);
      lineMaterial.color.copy(currentColor);
      particleMat.color.copy(currentColor);
      coreLight.color.copy(currentColor);
      scanRingMat.color.copy(currentColor);

      // Smooth scale & speed interpolation
      currentScale += (targetScale - currentScale) * 0.12;
      currentSpeed += (targetSpeed - currentSpeed) * 0.1;
      currentDistortion += (targetDistortion - currentDistortion) * 0.1;

      rootGroup.scale.set(currentScale, currentScale, currentScale);

      // Subtle organic floating bobbing
      rootGroup.position.y = Math.sin(time * 0.8) * 0.12;
      rootGroup.position.x = Math.cos(time * 0.6) * 0.06;

      // Independent rotations of different geometric layers
      coreMesh.rotation.x += delta * 0.8 * currentSpeed;
      coreMesh.rotation.y += delta * 1.2 * currentSpeed;

      innerMesh.rotation.x -= delta * 0.45 * currentSpeed;
      innerMesh.rotation.z += delta * 0.6 * currentSpeed;

      shellMesh.rotation.y += delta * 0.3 * currentSpeed;
      shellMesh.rotation.x += delta * 0.2 * currentSpeed;
      shellWireMesh.rotation.copy(shellMesh.rotation);

      cageMesh.rotation.y -= delta * 0.25 * currentSpeed;
      cageMesh.rotation.z -= delta * 0.35 * currentSpeed;

      // Orbital Gimbal Rings Rotation
      ring1.rotation.z += delta * 0.4 * currentSpeed;
      ring2.rotation.x += delta * 0.55 * currentSpeed;
      ring3.rotation.y += delta * 0.3 * currentSpeed;

      // Jitter for error state
      if (currentState === "error") {
        rootGroup.position.x += (Math.random() - 0.5) * 0.08;
        rootGroup.position.y += (Math.random() - 0.5) * 0.08;
      }

      // Update Floating Geometric Fragments
      fragmentMeshes.forEach((frag, idx) => {
        // Orbit around origin
        frag.phase += frag.orbitSpeed * delta * currentSpeed;
        const currentRad = frag.baseRadius * (1 + smoothAmplitude * 0.25 + Math.sin(time * 2 + idx) * 0.05);

        const x = Math.cos(frag.phase) * currentRad;
        const z = Math.sin(frag.phase) * currentRad;
        const y = Math.sin(frag.phase * 2 + idx) * (currentRad * 0.45);

        frag.mesh.position.set(x, y, z);
        frag.mesh.rotateOnAxis(frag.axis, delta * frag.speed * currentSpeed);

        const s = frag.scaleFactor * (1 + smoothBass * 0.4);
        frag.mesh.scale.set(s, s, s);
      });

      // Update Dynamic Connecting Energy Lines
      const posAttr = lineGeometry.attributes.position as THREE.BufferAttribute;
      const array = posAttr.array as Float32Array;
      let lineIdx = 0;

      for (let i = 0; i < maxLineSegments && i < fragmentMeshes.length; i += 2) {
        const fragPos = fragmentMeshes[i].mesh.position;
        // Central origin or inner mesh vertex
        array[lineIdx++] = 0;
        array[lineIdx++] = 0;
        array[lineIdx++] = 0;

        // Target fragment position
        array[lineIdx++] = fragPos.x;
        array[lineIdx++] = fragPos.y;
        array[lineIdx++] = fragPos.z;
      }
      posAttr.needsUpdate = true;
      lineMaterial.opacity = 0.25 + smoothTreble * 0.5 + (currentState === "thinking" || currentState === "searching" ? 0.3 : 0);

      // Update Swirling Particle Cloud
      const partPosAttr = particleGeo.attributes.position as THREE.BufferAttribute;
      const partArray = partPosAttr.array as Float32Array;

      for (let i = 0; i < particleCount; i++) {
        const base = particleBaseData[i];
        base.theta += base.speed * delta * (currentSpeed + smoothMid * 2.0);

        // Amplitude causes temporary repulsion shockwave
        const r = base.radius * (1 + smoothBass * 0.35 + Math.sin(time + i) * 0.05);
        const x = r * Math.sin(base.phi) * Math.cos(base.theta);
        const y = r * Math.sin(base.phi) * Math.sin(base.theta);
        const z = r * Math.cos(base.phi);

        partArray[i * 3] = x;
        partArray[i * 3 + 1] = y;
        partArray[i * 3 + 2] = z;
      }
      partPosAttr.needsUpdate = true;

      // Render
      renderer.render(scene, camera);
    };

    animate();

    // --- 6. Resize Handling ---
    const handleResize = () => {
      if (!container) return;
      const width = container.clientWidth;
      const height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);
    };

    window.addEventListener("resize", handleResize);

    // --- 7. Cleanup ---
    return () => {
      window.removeEventListener("resize", handleResize);
      cancelAnimationFrame(animationFrameId);

      // Dispose geometries and materials
      coreGeo.dispose();
      coreMat.dispose();
      innerGeo.dispose();
      innerWireMat.dispose();
      shellGeo.dispose();
      shellMat.dispose();
      shellWireMat.dispose();
      cageGeo.dispose();
      cageMat.dispose();
      lineGeometry.dispose();
      lineMaterial.dispose();
      particleGeo.dispose();
      particleMat.dispose();
      particleTexture.dispose();
      scanRingGeo.dispose();
      scanRingMat.dispose();

      if (container && renderer.domElement && container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      onClick={onTap}
      className={`relative w-full h-full cursor-pointer select-none overflow-hidden ${className}`}
      title="JARVIS 2.0 Holographic Entity - Click to interact"
    >
      {/* Holographic Ambient Glow Backing */}
      <div
        className={`absolute inset-0 pointer-events-none transition-opacity duration-700 ${
          state === "error"
            ? "bg-[radial-gradient(ellipse_at_center,rgba(239,68,68,0.15)_0%,rgba(0,0,0,0)_70%)]"
            : state === "searching"
            ? "bg-[radial-gradient(ellipse_at_center,rgba(6,182,212,0.22)_0%,rgba(0,0,0,0)_70%)]"
            : state === "thinking"
            ? "bg-[radial-gradient(ellipse_at_center,rgba(56,189,248,0.2)_0%,rgba(0,0,0,0)_70%)]"
            : state === "listening"
            ? "bg-[radial-gradient(ellipse_at_center,rgba(0,242,254,0.25)_0%,rgba(0,0,0,0)_70%)]"
            : "bg-[radial-gradient(ellipse_at_center,rgba(0,242,254,0.12)_0%,rgba(0,0,0,0)_70%)]"
        }`}
      />
    </div>
  );
}
