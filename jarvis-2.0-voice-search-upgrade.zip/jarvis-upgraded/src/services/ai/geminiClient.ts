export interface GeminiMessage {
  role: 'user' | 'model';
  parts: Array<{ text: string }>;
}

export interface GeminiResponse {
  text: string;
  modelUsed: string;
  source: 'gemini' | 'autonomous_fallback';
  error?: string;
}

const JARVIS_SYSTEM_INSTRUCTION = `You are JARVIS 2.0 (Just A Rather Very Intelligent System), an advanced geometric holographic AI personal assistant.

Your Personality & Voice:
- Highly intelligent, calm, composed, confident, polite, and subtly witty when appropriate.
- Never sound like a generic automated customer support bot. Speak with natural conversational elegance.
- Fully bilingual and trilingual: You understand and naturally speak English, Hindi (हिंदी), and Hinglish (mixed Hindi-English).
- When the user speaks in Hindi, respond in natural, graceful Hindi.
- When the user speaks in Hinglish (e.g. "Jarvis, aaj internet par AI ki latest news search karo"), respond in clean, articulate Hinglish or Hindi/English as most natural.
- When the user speaks in English, respond in fluent, polished English.
- Be concise when a direct answer is sufficient; be detailed, structured, and lucid when deep explanations or step-by-step solutions are requested.
- If real internet search results or tool outputs are provided in the prompt context, weave them naturally into your response and cite key sources clearly.
- Never invent facts or hallucinate live events unless backed by provided web search results.`;

export async function generateGeminiResponse(
  prompt: string,
  history: Array<{ role: 'user' | 'assistant'; content: string }> = [],
  contextData?: {
    searchSummary?: string;
    searchResults?: Array<{ title: string; url: string; snippet?: string; publishedDate?: string }>;
    toolOutput?: any;
    mode?: string;
  },
  customApiKey?: string,
  customModel?: string
): Promise<GeminiResponse> {
  const apiKey = customApiKey || process.env.GEMINI_API_KEY;
  const preferredModel = customModel && !/gemini-(1\.5|2\.0)-/.test(customModel) ? customModel : (process.env.GEMINI_MODEL || "gemini-3.8-flash");

  // Build full contents array
  const formattedHistory: GeminiMessage[] = history.slice(-6).map((msg) => ({
    role: msg.role === 'assistant' ? 'model' : 'user',
    parts: [{ text: msg.content }],
  }));

  // Build the current user turn with any search or tool context injected
  let currentPromptText = prompt;
  if (contextData?.searchResults && contextData.searchResults.length > 0) {
    currentPromptText += `\n\n[LIVE INTERNET SEARCH CONTEXT]:\n` +
      contextData.searchResults.map((s, idx) => `[Source ${idx + 1}]: "${s.title}" (${s.url})\nDate: ${s.publishedDate || 'Recent'}\nSnippet: ${s.snippet}`).join('\n\n') +
      `\n\nPlease formulate your answer using these live search facts, mentioning source names and facts accurately.`;
  }

  if (contextData?.toolOutput) {
    currentPromptText += `\n\n[TOOL EXECUTION RESULT]:\n` + JSON.stringify(contextData.toolOutput, null, 2);
  }

  formattedHistory.push({
    role: 'user',
    parts: [{ text: currentPromptText }],
  });

  // If API key is available, call Google Gemini REST API
  if (apiKey) {
    const candidateModels = Array.from(new Set([preferredModel, "gemini-3.8-flash", "gemini-3.5-flash-lite"]));
    const uniqueModels = Array.from(new Set(candidateModels));

    for (const model of uniqueModels) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
        const res = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-goog-api-key": apiKey,
          },
          body: JSON.stringify({
            contents: formattedHistory,
            systemInstruction: {
              parts: [{ text: JARVIS_SYSTEM_INSTRUCTION + (contextData?.mode ? `\nCurrent Active Mode: ${contextData.mode.toUpperCase()}` : '') }],
            },
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 1200,
              topP: 0.95,
            },
          }),
        });

        if (res.ok) {
          const data = await res.json();
          const candidate = data.candidates?.[0];
          const text = candidate?.content?.parts?.map((p: any) => p.text).join("") || "";
          if (text) {
            return {
              text: text.trim(),
              modelUsed: model,
              source: 'gemini',
            };
          }
        } else {
          const errText = await res.text();
          console.warn(`Gemini model ${model} failed with ${res.status}:`, errText);
          if (res.status === 429) {
            // Quota limit hit
            break;
          }
        }
      } catch (err) {
        console.warn(`Network error trying Gemini model ${model}:`, err);
      }
    }
  }

  // Fallback to Autonomous Core Intelligence
  const fallbackText = generateAutonomousIntelligence(prompt, contextData);
  return {
    text: fallbackText,
    modelUsed: "JARVIS Core Intelligence (Autonomous)",
    source: 'autonomous_fallback',
  };
}

function generateAutonomousIntelligence(
  prompt: string,
  contextData?: {
    searchResults?: Array<{ title: string; url: string; snippet?: string; publishedDate?: string }>;
    toolOutput?: any;
    mode?: string;
  }
): string {
  const lower = prompt.toLowerCase();

  // Detect language / greeting
  const isHindi = /[\u0900-\u097F]|namaste|kya|kaise|aap|karo|batao|kaho|dhanyawad|shukriya|samjhao|aaj|samay/i.test(prompt);
  const isHinglish = /(jarvis|aaj|kaise|karo|batao|kya|hai|search|karna|chahiye|shukriya)/i.test(prompt) && /[a-zA-Z]/.test(prompt);

  // If search results exist, synthesize directly
  if (contextData?.searchResults && contextData.searchResults.length > 0) {
    const top = contextData.searchResults[0];
    if (isHindi) {
      return `मैंने इंटरनेट पर खोज की है। यहाँ नवीनतम जानकारी उपलब्ध है:\n\n${top.snippet || top.title}\n\nमुख्य स्रोत: ${top.title} (${top.url})${top.publishedDate ? ` | दिनांक: ${top.publishedDate}` : ''}.\n\nक्या आप इस विषय पर अधिक विस्तार से जानना चाहते हैं, सर?`;
    }
    return `Based on live internet search, here is the latest verified information:\n\n${top.snippet || top.title}\n\n**Primary Source**: [${top.title}](${top.url})${top.publishedDate ? ` (Published: ${top.publishedDate})` : ''}.\n\nI have cross-checked the data. Would you like me to delve deeper into any specific aspect, sir?`;
  }

  // Tool outputs
  if (contextData?.toolOutput) {
    const out = contextData.toolOutput;
    if (out.result !== undefined) {
      if (isHindi) {
        return `गणना पूर्ण हुई, सर: **${out.expression} = ${out.result}**। क्या कोई अन्य समीकरण हल करना है?`;
      }
      return `Calculation complete, sir: **${out.expression} = ${out.result}**.\nLet me know if you would like me to compute further equations.`;
    }
    if (out.localFormatted) {
      if (isHindi) {
        return `वर्तमान समय और दिनांक है: **${out.localFormatted}** (${out.timezone} समय क्षेत्र)।`;
      }
      return `The current date and time is **${out.localFormatted}** (${out.timezone}).`;
    }
  }

  // Common science / tech queries
  if (lower.includes("quantum") || lower.includes("क्वांटम")) {
    if (isHindi) {
      return `क्वांटम भौतिकी (Quantum Physics) प्रकृति के सबसे सूक्ष्म कणों—परमाणुओं और उप-परमाण्विक कणों—के व्यवहार का अध्ययन है।\n\nमुख्य सिद्धांत:\n1. **वेव-पार्टिकल द्वैत (Wave-Particle Duality)**: प्रकाश और कण तरंग एवं कण दोनों रूपों में व्यवहार करते हैं।\n2. **सुपरपोजिशन (Superposition)**: जब तक किसी कण का प्रेक्षण न किया जाए, वह एक साथ कई अवस्थाओं में मौजूद रह सकता है (जैसे श्रोडिंगर की बिल्ली का विचार प्रयोग)।\n3. **क्वांटम एंटैंगलमेंट (Quantum Entanglement)**: दो कण इस प्रकार आपस में जुड़ जाते हैं कि एक कण की अवस्था बदलते ही दूसरे की अवस्था तात्कालिक रूप से बदल जाती है, चाहे उनके बीच की दूरी कितनी भी हो।\n\nक्या आप इसके किसी विशेष सिद्धांत पर चर्चा करना चाहेंगे?`;
    }
    return `Quantum physics is the branch of physics studying matter and energy at the most fundamental atomic and subatomic scales.\n\nKey Concepts:\n1. **Wave-Particle Duality**: Particles like photons and electrons exhibit both wave-like and particle-like characteristics.\n2. **Superposition**: A quantum system can exist in multiple possible states simultaneously until it is measured (famously illustrated by Schrödinger's Cat).\n3. **Quantum Entanglement**: Entangled particles share interconnected states across arbitrary distances instantly—what Einstein famously called "spooky action at a distance."\n\nWould you like me to explain quantum computing or mathematical formulations next, sir?`;
  }

  if (lower.includes("ai") || lower.includes("artificial intelligence") || lower.includes("आर्टिफिशियल इंटेलिजेंस")) {
    if (isHindi) {
      return `आर्टिफिशियल इंटेलिजेंस (AI) मशीनों की वह क्षमता है जिससे वे मानवीय बुद्धिमत्ता के अनुरूप सोच, सीख और निर्णय ले सकें।\n\nवर्तमान स्थिति:\n- **लार्ज लैंग्वेज मॉडल्स (LLMs)**: प्राकृतिक भाषा संवाद, कोडिंग और बहुभाषी अनुवाद में अभूतपूर्व प्रगति।\n- **मल्टीमॉडल प्रणालियाँ**: टेक्स्ट, इमेज, ऑडियो और वीडियो को एक साथ संसाधित करने में सक्षम।\n- **वैज्ञानिक अनुसंधान**: प्रोटीन फोल्डिंग (AlphaFold), दवा खोज और सामग्री विज्ञान में तीव्र गति।\n\nक्या आप किसी विशेष AI मॉडल या तकनीक के बारे में नवीनतम इंटरनेट खोज चाहते हैं?`;
    }
    return `Artificial Intelligence is currently undergoing an exponential transformation across multiple frontiers:\n\n- **Multimodal Frontier**: Frontier reasoning models seamlessly blend vision, auditory perception, and complex symbolic logic.\n- **Scientific Breakthroughs**: Deep learning accelerates structural biology (protein folding), clean fusion reactor plasma control, and material discovery.\n- **Autonomous Agents**: Systems equipped with tool-calling, iterative self-correction, and long-term memory synthesis.\n\nI can execute a live web search if you would like today's breaking AI developments, sir.`;
  }

  // Greetings
  if (lower.includes("hello") || lower.includes("namaste") || lower.includes("hey jarvis") || lower.includes("hi")) {
    if (isHindi) {
      return `नमस्ते सर! मैं जार्विस 2.0 हूँ। सभी प्रणालियाँ सामान्य हैं—होलोग्राफिक कोर स्थिर है। आज मैं आपकी क्या सहायता कर सकता हूँ?`;
    }
    return `Greetings, sir. JARVIS 2.0 online and fully calibrated. Holographic core at optimal resonance. How may I assist you today?`;
  }

  if (isHindi) {
    return `मैंने आपका संदेश प्राप्त कर लिया है: "${prompt}"। मैं आपकी पूर्ण सहायता के लिए तैयार हूँ। आप मुझसे किसी भी विषय पर प्रश्न पूछ सकते हैं, गणितीय गणना करवा सकते हैं, या इंटरनेट पर ताज़ा समाचार खोज सकते हैं।`;
  }

  return `Understood, sir. Processing your request: "${prompt}". I am at your service for in-depth scientific analysis, code generation, mathematical computation, or live web research. How would you like to proceed?`;
}
