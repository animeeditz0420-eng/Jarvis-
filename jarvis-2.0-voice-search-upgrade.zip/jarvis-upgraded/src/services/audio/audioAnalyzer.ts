import { AudioAnalysisData } from "@/types/jarvis";

class AudioAnalyzerManager {
  private audioContext: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private syntheticOscillator: OscillatorNode | null = null;
  private syntheticGain: GainNode | null = null;
  private frequencyDataArray: Uint8Array = new Uint8Array(128);
  private timeDataArray: Uint8Array = new Uint8Array(128);
  private isListening: boolean = false;
  private isSpeaking: boolean = false;
  private speechEnvelopeTimer: number | null = null;
  private simulatedAmplitude: number = 0;

  constructor() {
    // Lazy initialize on user gesture
  }

  public initContext(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.audioContext) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        this.audioContext = new AudioCtx();
        this.analyser = this.audioContext.createAnalyser();
        this.analyser.fftSize = 256;
        this.analyser.smoothingTimeConstant = 0.82;
        this.frequencyDataArray = new Uint8Array(this.analyser.frequencyBinCount);
        this.timeDataArray = new Uint8Array(this.analyser.frequencyBinCount);
      }
    }
    if (this.audioContext && this.audioContext.state === "suspended") {
      this.audioContext.resume().catch(() => {});
    }
    return this.audioContext;
  }

  public async connectMicrophone(): Promise<boolean> {
    const ctx = this.initContext();
    if (!ctx || !this.analyser) return false;

    try {
      if (this.micStream) {
        this.disconnectMicrophone();
      }

      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      this.micSource = ctx.createMediaStreamSource(this.micStream);
      this.micSource.connect(this.analyser);
      this.isListening = true;
      return true;
    } catch (err) {
      console.warn("Microphone access not granted or failed:", err);
      this.isListening = false;
      return false;
    }
  }

  public disconnectMicrophone(): void {
    if (this.micSource) {
      try {
        this.micSource.disconnect();
      } catch {}
      this.micSource = null;
    }
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    this.isListening = false;
  }

  public startSpeechAudioSimulation(speechText: string): void {
    this.initContext();
    this.isSpeaking = true;

    // Use Web Audio oscillator modulated at speaking cadence so the AnalyserNode receives genuine audio waveforms
    if (this.audioContext && this.analyser) {
      try {
        if (!this.syntheticGain) {
          this.syntheticGain = this.audioContext.createGain();
          this.syntheticGain.gain.value = 0.001; // Inaudible or very quiet so it doesn't double speech synthesis sound
          this.syntheticGain.connect(this.analyser);
        }

        if (!this.syntheticOscillator) {
          this.syntheticOscillator = this.audioContext.createOscillator();
          this.syntheticOscillator.type = "sawtooth";
          this.syntheticOscillator.frequency.value = 180; // fundamental voice pitch
          this.syntheticOscillator.connect(this.syntheticGain);
          this.syntheticOscillator.start();
        }

        // Modulate gain rhythmically to simulate human speech envelope
        const cadence = () => {
          if (!this.isSpeaking) return;
          const randomAmp = 0.2 + Math.random() * 0.7;
          this.simulatedAmplitude = randomAmp;
          if (this.syntheticGain && this.audioContext) {
            const now = this.audioContext.currentTime;
            this.syntheticGain.gain.setValueAtTime(randomAmp * 0.15, now);
            this.syntheticGain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);
          }
          this.speechEnvelopeTimer = window.setTimeout(cadence, 90 + Math.random() * 80);
        };
        cadence();
      } catch (e) {
        console.warn("Speech simulation node setup failed:", e);
      }
    }
  }

  public stopSpeechAudioSimulation(): void {
    this.isSpeaking = false;
    this.simulatedAmplitude = 0;
    if (this.speechEnvelopeTimer) {
      clearTimeout(this.speechEnvelopeTimer);
      this.speechEnvelopeTimer = null;
    }
    if (this.syntheticGain && this.audioContext) {
      try {
        this.syntheticGain.gain.setValueAtTime(0, this.audioContext.currentTime);
      } catch {}
    }
  }

  public getAnalysis(): AudioAnalysisData {
    if (!this.analyser) {
      return {
        amplitude: this.isSpeaking ? this.simulatedAmplitude : 0,
        bass: 0,
        mid: 0,
        treble: 0,
        frequencyData: this.frequencyDataArray,
      };
    }

    this.analyser.getByteFrequencyData(this.frequencyDataArray as any);
    this.analyser.getByteTimeDomainData(this.timeDataArray as any);

    // Calculate RMS amplitude from time-domain data
    let sumSquares = 0;
    for (let i = 0; i < this.timeDataArray.length; i++) {
      const normalized = (this.timeDataArray[i] - 128) / 128;
      sumSquares += normalized * normalized;
    }
    const rms = Math.sqrt(sumSquares / this.timeDataArray.length);
    let amplitude = Math.min(1.0, rms * 2.8);

    if (this.isSpeaking && amplitude < 0.1) {
      amplitude = Math.max(amplitude, this.simulatedAmplitude);
    }

    // Frequency bands
    const binCount = this.frequencyDataArray.length;
    const bassEnd = Math.floor(binCount * 0.15);
    const midEnd = Math.floor(binCount * 0.55);

    let bassSum = 0;
    for (let i = 0; i < bassEnd; i++) bassSum += this.frequencyDataArray[i];
    const bass = bassSum / (bassEnd * 255 || 1);

    let midSum = 0;
    for (let i = bassEnd; i < midEnd; i++) midSum += this.frequencyDataArray[i];
    const mid = midSum / ((midEnd - bassEnd) * 255 || 1);

    let trebleSum = 0;
    for (let i = midEnd; i < binCount; i++) trebleSum += this.frequencyDataArray[i];
    const treble = trebleSum / ((binCount - midEnd) * 255 || 1);

    return {
      amplitude,
      bass,
      mid,
      treble,
      frequencyData: this.frequencyDataArray,
    };
  }

  public cleanup(): void {
    this.disconnectMicrophone();
    this.stopSpeechAudioSimulation();
    if (this.syntheticOscillator) {
      try {
        this.syntheticOscillator.stop();
        this.syntheticOscillator.disconnect();
      } catch {}
      this.syntheticOscillator = null;
    }
    if (this.audioContext) {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }
  }
}

export const audioAnalyzer = new AudioAnalyzerManager();
