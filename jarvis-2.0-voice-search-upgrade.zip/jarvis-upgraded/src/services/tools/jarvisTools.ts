import { ToolCallData } from "@/types/jarvis";

export interface ToolDefinition {
  id: string;
  name: string;
  description: string;
  parameters: Record<string, any>;
  requiresConfirmation?: boolean;
}

export const JARVIS_TOOLS: ToolDefinition[] = [
  {
    id: "calculator",
    name: "Calculator",
    description: "Evaluates mathematical equations, expressions, percentages, and scientific calculations.",
    parameters: {
      type: "object",
      properties: {
        expression: { type: "string", description: "Mathematical expression like '45 * 12 + sqrt(144)' or '25% of 850'" }
      },
      required: ["expression"]
    }
  },
  {
    id: "datetime",
    name: "Current Date and Time",
    description: "Fetches accurate current date, time, day, timezone, and calendar details.",
    parameters: {
      type: "object",
      properties: {
        timezone: { type: "string", description: "Optional timezone like 'Asia/Kolkata' or 'UTC'" }
      }
    }
  },
  {
    id: "timer",
    name: "Timer & Countdown",
    description: "Sets an active countdown timer or alert for a specified duration in seconds or minutes.",
    parameters: {
      type: "object",
      properties: {
        seconds: { type: "number", description: "Duration in seconds" },
        label: { type: "string", description: "Reason or label for timer" }
      },
      required: ["seconds"]
    }
  },
  {
    id: "notes",
    name: "Notes Manager",
    description: "Saves a quick note or retrieves notes for the user.",
    parameters: {
      type: "object",
      properties: {
        action: { type: "string", enum: ["save", "list"], description: "Action to perform" },
        title: { type: "string", description: "Note title" },
        content: { type: "string", description: "Note content" },
        tags: { type: "string", description: "Comma-separated tags" }
      },
      required: ["action"]
    }
  },
  {
    id: "reminder",
    name: "Reminder Manager",
    description: "Sets a task reminder with due time.",
    parameters: {
      type: "object",
      properties: {
        text: { type: "string", description: "Reminder task or event" },
        dueTime: { type: "string", description: "Due time or relative description e.g. 'In 1 hour' or '8:00 PM'" }
      },
      required: ["text", "dueTime"]
    }
  },
  {
    id: "website_opener",
    name: "Website Opener",
    description: "Prepares a safe link to open a popular or user-requested website with explicit user confirmation.",
    requiresConfirmation: true,
    parameters: {
      type: "object",
      properties: {
        url: { type: "string", description: "Full valid URL starting with https://" },
        siteName: { type: "string", description: "Readable name of the site e.g. 'GitHub', 'Wikipedia', 'YouTube'" }
      },
      required: ["url", "siteName"]
    }
  },
  {
    id: "study_assistant",
    name: "Educational & Study Assistant",
    description: "Generates structured step-by-step educational explanations, formula derivations, or quiz questions.",
    parameters: {
      type: "object",
      properties: {
        topic: { type: "string", description: "Topic or subject e.g. Quantum Entanglement, Calculus, Photosynthesis" },
        level: { type: "string", enum: ["simple", "intermediate", "advanced"], description: "Depth of explanation" }
      },
      required: ["topic"]
    }
  },
  {
    id: "code_generator",
    name: "Code Generator",
    description: "Generates clean, production-ready, documented code snippets for requested programming tasks.",
    parameters: {
      type: "object",
      properties: {
        language: { type: "string", description: "Target programming language" },
        specification: { type: "string", description: "Functionality requirements" }
      },
      required: ["language", "specification"]
    }
  }
];

export function executeSafeCalculator(expr: string): { expression: string; result: number | string; success: boolean } {
  try {
    // Sanitize expression
    let cleaned = expr
      .replace(/×/g, "*")
      .replace(/÷/g, "/")
      .replace(/π/g, "Math.PI")
      .replace(/pi/gi, "Math.PI")
      .replace(/sqrt\(/gi, "Math.sqrt(")
      .replace(/sin\(/gi, "Math.sin(")
      .replace(/cos\(/gi, "Math.cos(")
      .replace(/tan\(/gi, "Math.tan(")
      .replace(/pow\(/gi, "Math.pow(")
      .replace(/abs\(/gi, "Math.abs(")
      .replace(/log\(/gi, "Math.log10(")
      .replace(/ln\(/gi, "Math.log(");

    // Handle percentage e.g. "25% of 800" or "800 * 25%"
    const percentMatch = cleaned.match(/(\d+(?:\.\d+)?)\s*%\s*(?:of\s*)?(\d+(?:\.\d+)?)/i);
    if (percentMatch) {
      const p = parseFloat(percentMatch[1]);
      const v = parseFloat(percentMatch[2]);
      return { expression: expr, result: (p / 100) * v, success: true };
    }

    // Only allow safe math tokens
    if (!/^[0-9+\-*/()., %^eE\sMathPIsqrtincoanpwbslg]+$/.test(cleaned)) {
      return { expression: expr, result: "Invalid characters in expression", success: false };
    }

    // Replace ^ with ** for exponentiation
    cleaned = cleaned.replace(/\^/g, "**");

    // Safe execution in isolated Function context without access to window/process
    const fn = new Function(`"use strict"; return (${cleaned});`);
    const val = fn();

    if (typeof val !== "number" || isNaN(val)) {
      return { expression: expr, result: "Unable to calculate expression", success: false };
    }

    // Format output
    const formatted = Number.isInteger(val) ? val : parseFloat(val.toFixed(6));
    return { expression: expr, result: formatted, success: true };
  } catch (err: any) {
    return { expression: expr, result: err.message || "Calculation error", success: false };
  }
}

export function executeDateTime(tz?: string): any {
  const timezone = tz || "Asia/Kolkata";
  try {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat("en-IN", {
      timeZone: timezone,
      dateStyle: "full",
      timeStyle: "long",
    });
    const formattedIST = formatter.format(now);
    const utcDate = now.toUTCString();

    return {
      localFormatted: formattedIST,
      timezone,
      utc: utcDate,
      iso: now.toISOString(),
      timestamp: now.getTime(),
    };
  } catch {
    const now = new Date();
    return {
      localFormatted: now.toLocaleString(),
      timezone: "Local",
      utc: now.toUTCString(),
      iso: now.toISOString(),
    };
  }
}
