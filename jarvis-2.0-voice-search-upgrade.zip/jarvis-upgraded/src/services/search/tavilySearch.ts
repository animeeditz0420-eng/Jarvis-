import { SourceCitation } from "@/types/jarvis";

export interface TavilySearchOptions {
  query: string;
  searchDepth?: "basic" | "advanced";
  maxResults?: number;
  includeAnswer?: boolean;
  apiKey?: string;
}

export interface TavilySearchResponse {
  answer?: string;
  query: string;
  results: SourceCitation[];
  status: "success" | "no_key" | "error";
  errorMessage?: string;
}

export async function performTavilySearch(options: TavilySearchOptions): Promise<TavilySearchResponse> {
  const apiKey = options.apiKey?.trim() || process.env.TAVILY_API_KEY?.trim();

  if (!apiKey) {
    return {
      query: options.query,
      results: [],
      status: "no_key",
      errorMessage: "Tavily API key is missing. Add a free Tavily key in JARVIS Settings to enable live web search.",
    };
  }

  try {
    const response = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        query: options.query,
        search_depth: options.searchDepth || "basic",
        max_results: Math.min(Math.max(options.maxResults || 5, 1), 10),
        include_answer: options.includeAnswer !== false,
        include_raw_content: false,
      }),
      signal: AbortSignal.timeout(15_000),
    });

    const raw = await response.text();
    let data: any = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch {}

    if (!response.ok) {
      const detail = data?.detail?.error || data?.detail || data?.message || `HTTP ${response.status}`;
      return {
        query: options.query,
        results: [],
        status: "error",
        errorMessage: `Tavily search failed (${response.status}): ${typeof detail === "string" ? detail : JSON.stringify(detail)}`,
      };
    }

    const citations: SourceCitation[] = (Array.isArray(data.results) ? data.results : [])
      .filter((r: any) => typeof r.url === "string" && /^https?:\/\//i.test(r.url))
      .map((r: any) => ({
        title: r.title || "Web result",
        url: r.url,
        snippet: r.content || r.snippet || "",
        publishedDate: r.published_date || undefined,
        score: typeof r.score === "number" ? r.score : undefined,
      }));

    return {
      answer: typeof data.answer === "string" ? data.answer : undefined,
      query: options.query,
      results: citations,
      status: "success",
    };
  } catch (error: any) {
    return {
      query: options.query,
      results: [],
      status: "error",
      errorMessage: error?.name === "TimeoutError"
        ? "Tavily search timed out. Please try again."
        : error?.message || "Could not connect to Tavily Search.",
    };
  }
}
