export type HologramState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'searching' | 'error';

export type JarvisMode = 'assistant' | 'search' | 'study' | 'research' | 'developer';

export type QualityMode = 'performance' | 'balanced' | 'high';

export type VoiceLanguage = 'auto' | 'hi' | 'en' | 'hinglish';

export interface SourceCitation {
  title: string;
  url: string;
  snippet?: string;
  publishedDate?: string;
  score?: number;
}

export interface ToolCallData {
  toolName: string;
  input: any;
  output: any;
  requiresConfirmation?: boolean;
  status: 'pending' | 'executed' | 'cancelled' | 'failed';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  language?: string;
  sources?: SourceCitation[];
  toolData?: ToolCallData;
  createdAt: string;
}

export interface ConversationSession {
  id: string;
  title: string;
  mode: JarvisMode;
  createdAt: string;
  updatedAt: string;
}

export interface NoteItem {
  id: number;
  title: string;
  content: string;
  tags?: string;
  createdAt: string;
}

export interface ReminderItem {
  id: number;
  text: string;
  dueTime: string;
  completed: boolean;
  createdAt: string;
}

export interface AudioAnalysisData {
  amplitude: number;
  bass: number;
  mid: number;
  treble: number;
  frequencyData: Uint8Array;
}

export interface SystemStatusData {
  aiStatus: 'connected' | 'not_configured' | 'quota_exceeded' | 'error';
  aiModel: string;
  searchStatus: 'connected' | 'not_configured' | 'quota_exceeded' | 'error';
  databaseStatus: 'connected' | 'error';
  micStatus: 'ready' | 'listening' | 'denied' | 'unsupported';
  voiceEngineStatus: 'ready' | 'speaking' | 'unsupported';
  latencyMs?: number;
}
