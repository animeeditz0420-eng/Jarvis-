"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import GeometricHologram from "@/components/hologram/GeometricHologram";
import Header from "@/components/dashboard/Header";
import SystemDiagnostics from "@/components/dashboard/SystemDiagnostics";
import ConversationSidebar from "@/components/dashboard/ConversationSidebar";
import FloatingResponsePanel from "@/components/chat/FloatingResponsePanel";
import BottomControls from "@/components/controls/BottomControls";
import SettingsModal from "@/components/modals/SettingsModal";
import { useVoiceEngine } from "@/hooks/useVoiceEngine";
import {
  HologramState,
  JarvisMode,
  QualityMode,
  ChatMessage,
  ConversationSession,
  NoteItem,
  ReminderItem,
  SystemStatusData,
  ToolCallData,
} from "@/types/jarvis";

export default function JarvisApp() {
  // --- Hologram & Mode States ---
  const [hologramState, setHologramState] = useState<HologramState>("idle");
  const [mode, setMode] = useState<JarvisMode>("assistant");
  const [quality, setQuality] = useState<QualityMode>("balanced");

  // --- UI Panels Visibility ---
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(true);

  // --- Conversations & Messages ---
  const [activeSessionId, setActiveSessionId] = useState<string | undefined>(undefined);
  const [sessions, setSessions] = useState<ConversationSession[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [lastUserMessage, setLastUserMessage] = useState<string>("");
  const [lastAssistantMessage, setLastAssistantMessage] = useState<ChatMessage | null>(null);

  // --- Stored Notes & Reminders ---
  const [notesList, setNotesList] = useState<NoteItem[]>([]);
  const [remindersList, setRemindersList] = useState<ReminderItem[]>([]);

  // --- Active Tool & Timer ---
  const [activeTool, setActiveTool] = useState<ToolCallData | undefined>(undefined);
  const [activeTimer, setActiveTimer] = useState<{
    secondsLeft: number;
    totalSeconds: number;
    label: string;
  } | null>(null);

  // --- System Diagnostics Telemetry ---
  const [systemStatus, setSystemStatus] = useState<SystemStatusData>({
    aiStatus: "not_configured",
    aiModel: "gemini-3.8-flash",
    searchStatus: "not_configured",
    databaseStatus: "connected",
    micStatus: "ready",
    voiceEngineStatus: "ready",
  });

  // --- Configurable Credentials & Settings (Stored in LocalStorage) ---
  const [customGeminiKey, setCustomGeminiKey] = useState<string>("");
  const [customTavilyKey, setCustomTavilyKey] = useState<string>("");
  const [selectedModel, setSelectedModel] = useState<string>("gemini-3.8-flash");
  const [wakeWord, setWakeWord] = useState<string>("jarvis");
  const [wakeWordEnabled, setWakeWordEnabled] = useState<boolean>(false);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  // --- Load Saved Preferences from LocalStorage on mount ---
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const savedGemini = localStorage.getItem("jarvis_gemini_key") || "";
      const savedTavily = localStorage.getItem("jarvis_tavily_key") || "";
      const savedModel = localStorage.getItem("jarvis_model") || "gemini-3.8-flash";
      const savedQuality = (localStorage.getItem("jarvis_quality") as QualityMode) || "balanced";
      const savedWake = localStorage.getItem("jarvis_wake_word") || "jarvis";
      const savedWakeEnabled = localStorage.getItem("jarvis_wake_enabled") === "true";

      if (savedGemini) setCustomGeminiKey(savedGemini);
      if (savedTavily) setCustomTavilyKey(savedTavily);
      if (savedModel) {
        const migratedModel = /gemini-(1\.5|2\.0)-/.test(savedModel) ? "gemini-3.8-flash" : savedModel;
        setSelectedModel(migratedModel);
        if (migratedModel !== savedModel) localStorage.setItem("jarvis_model", migratedModel);
      }
      if (savedQuality) setQuality(savedQuality);
      if (savedWake) setWakeWord(savedWake);
      setWakeWordEnabled(savedWakeEnabled);
    } catch {}
  }, []);

  // --- Save helpers ---
  const handleSaveGeminiKey = (key: string) => {
    setCustomGeminiKey(key);
    try {
      localStorage.setItem("jarvis_gemini_key", key);
    } catch {}
  };

  const handleSaveTavilyKey = (key: string) => {
    setCustomTavilyKey(key);
    try {
      localStorage.setItem("jarvis_tavily_key", key);
    } catch {}
  };

  const handleSelectModel = (model: string) => {
    setSelectedModel(model);
    try {
      localStorage.setItem("jarvis_model", model);
    } catch {}
  };

  const handleQualityChange = (q: QualityMode) => {
    setQuality(q);
    try {
      localStorage.setItem("jarvis_quality", q);
    } catch {}
  };

  const handleSaveWakeWord = (word: string) => {
    setWakeWord(word);
    try {
      localStorage.setItem("jarvis_wake_word", word);
    } catch {}
  };

  const handleToggleWakeWord = (enabled: boolean) => {
    setWakeWordEnabled(enabled);
    try {
      localStorage.setItem("jarvis_wake_enabled", enabled ? "true" : "false");
    } catch {}
  };

  // --- Refresh System Status ---
  const refreshSystemStatus = useCallback(async () => {
    try {
      const res = await fetch("/api/status");
      if (res.ok) {
        const data = await res.json();
        setSystemStatus((prev) => ({
          ...prev,
          aiStatus: customGeminiKey ? "connected" : data.aiStatus,
          aiModel: selectedModel || data.aiModel,
          searchStatus: customTavilyKey ? "connected" : data.searchStatus,
          databaseStatus: data.databaseStatus,
          latencyMs: data.latencyMs,
        }));
      }
    } catch (e) {
      console.warn("Status fetch failed:", e);
    }
  }, [customGeminiKey, customTavilyKey, selectedModel]);

  // --- Fetch Sessions, Notes, Reminders ---
  const fetchSessions = async () => {
    try {
      const res = await fetch("/api/conversations");
      if (res.ok) {
        const data = await res.json();
        setSessions(data.conversations || []);
      }
    } catch {}
  };

  const fetchNotes = async () => {
    try {
      const res = await fetch("/api/notes");
      if (res.ok) {
        const data = await res.json();
        setNotesList(data.notes || []);
      }
    } catch {}
  };

  const fetchReminders = async () => {
    try {
      const res = await fetch("/api/reminders");
      if (res.ok) {
        const data = await res.json();
        setRemindersList(data.reminders || []);
      }
    } catch {}
  };

  useEffect(() => {
    refreshSystemStatus();
    fetchSessions();
    fetchNotes();
    fetchReminders();
  }, [refreshSystemStatus]);

  // --- Voice Engine Integration ---
  const {
    isListening,
    isSpeaking,
    isMuted,
    voiceError,
    setIsMuted,
    interimTranscript,
    speechLanguage,
    setSpeechLanguage,
    selectedVoice,
    setSelectedVoice,
    availableVoices,
    speechRate,
    setSpeechRate,
    speechPitch,
    setSpeechPitch,
    speechVolume,
    setSpeechVolume,
    startListening,
    stopListening,
    speak,
    stopSpeaking,
    continuousMode,
    setContinuousMode,
  } = useVoiceEngine({
    wakeWord,
    wakeWordEnabled,
    apiKey: customGeminiKey,
    onTranscriptReady: (transcript) => {
      handleSendMessage(transcript);
    },
  });

  // --- Voice diagnostics ---
  useEffect(() => {
    setSystemStatus((prev) => ({
      ...prev,
      micStatus: isListening ? "listening" : "ready",
      voiceEngineStatus: isSpeaking ? "speaking" : "ready",
    }));
  }, [isListening, isSpeaking]);

  // --- Hologram State Synchronization ---
  useEffect(() => {
    if (isListening) {
      setHologramState("listening");
    } else if (isProcessing) {
      // If web search is required or mode is search
      setHologramState(mode === "search" ? "searching" : "thinking");
    } else if (isSpeaking) {
      setHologramState("speaking");
    } else {
      setHologramState("idle");
    }
  }, [isListening, isProcessing, isSpeaking, mode]);

  // --- Active Countdown Timer Tick Loop ---
  useEffect(() => {
    if (!activeTimer || activeTimer.secondsLeft <= 0) return;

    const timerInterval = setInterval(() => {
      setActiveTimer((prev) => {
        if (!prev || prev.secondsLeft <= 1) {
          clearInterval(timerInterval);
          // Play audio beep when timer completes
          playAlarmTone();
          speak(`Timer alert, sir: your countdown for ${prev?.label || "the task"} has concluded.`);
          return null;
        }
        return { ...prev, secondsLeft: prev.secondsLeft - 1 };
      });
    }, 1000);

    return () => clearInterval(timerInterval);
  }, [activeTimer, speak]);

  const playAlarmTone = () => {
    if (typeof window === "undefined") return;
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioCtx) {
        const ctx = new AudioCtx();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.6);
        gain.gain.setValueAtTime(0.2, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.6);
      }
    } catch {}
  };

  // --- Send Message / Command Orchestration ---
  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isProcessing) return;

    setLastUserMessage(text.trim());
    setIsProcessing(true);
    stopSpeaking();

    // Prepare history snapshot
    const historyPayload = messages.slice(-4).map((m) => ({
      role: m.role,
      content: m.content,
    }));

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text.trim(),
          conversationId: activeSessionId,
          mode,
          history: historyPayload,
          language: speechLanguage,
          customGeminiKey: customGeminiKey || undefined,
          customTavilyKey: customTavilyKey || undefined,
          customModel: selectedModel,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `HTTP error ${res.status}`);
      }

      const data = await res.json();

      if (data.searchPerformed) {
        setSystemStatus((prev) => ({
          ...prev,
          searchStatus: data.searchStatus === "success" ? "connected" : "error",
        }));
      }

      // Update active session id
      if (data.conversationId && data.conversationId !== activeSessionId) {
        setActiveSessionId(data.conversationId);
        fetchSessions();
      }

      // Assistant Message Data
      const assistantMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: data.text,
        sources: data.sources || [],
        toolData: data.toolData,
        createdAt: new Date().toISOString(),
      };

      setLastAssistantMessage(assistantMsg);
      setMessages((prev) => [
        ...prev,
        { id: Math.random().toString(), role: "user", content: text.trim(), createdAt: new Date().toISOString() },
        assistantMsg,
      ]);

      // Handle Tool Specific Side Effects
      if (data.toolData) {
        setActiveTool(data.toolData);

        // Timer tool
        if (data.toolData.toolName === "timer" && data.toolData.output?.durationSeconds) {
          const sec = data.toolData.output.durationSeconds;
          setActiveTimer({
            secondsLeft: sec,
            totalSeconds: sec,
            label: data.toolData.input?.label || text,
          });
        }

        // Notes tool
        if (data.toolData.toolName === "notes") {
          fetchNotes();
        }

        // Reminder tool
        if (data.toolData.toolName === "reminder") {
          fetchReminders();
        }
      }

      // Voice Output: JARVIS speaks back
      if (!isMuted) {
        speak(data.text);
      }
    } catch (error: any) {
      console.error("Interaction failed:", error);
      setHologramState("error");

      const errorMsg: ChatMessage = {
        id: Math.random().toString(),
        role: "assistant",
        content: `I encountered an unexpected disruption while processing your command: ${error.message}. All primary diagnostic logs have been preserved.`,
        createdAt: new Date().toISOString(),
      };
      setLastAssistantMessage(errorMsg);

      if (!isMuted) {
        speak(errorMsg.content);
      }

      setTimeout(() => {
        setHologramState("idle");
      }, 3500);
    } finally {
      setIsProcessing(false);
    }
  };

  // --- Session Switching & Reset ---
  const handleSelectSession = async (id: string) => {
    setActiveSessionId(id);
    try {
      const res = await fetch(`/api/conversations?id=${id}`);
      if (res.ok) {
        const data = await res.json();
        const loadedMessages: ChatMessage[] = data.messages || [];
        setMessages(loadedMessages);
        if (loadedMessages.length > 0) {
          const lastMsg = loadedMessages[loadedMessages.length - 1];
          if (lastMsg.role === "assistant") {
            setLastAssistantMessage(lastMsg);
          }
        }
      }
    } catch {}
  };

  const handleNewSession = () => {
    setActiveSessionId(undefined);
    setMessages([]);
    setLastUserMessage("");
    setLastAssistantMessage(null);
    setActiveTool(undefined);
    speak("New conversation session initialized. At your command, sir.");
  };

  const handleDeleteSession = async (id: string) => {
    try {
      await fetch(`/api/conversations?id=${id}`, { method: "DELETE" });
      if (activeSessionId === id) {
        handleNewSession();
      }
      fetchSessions();
    } catch {}
  };

  const handleClearAllMemory = async () => {
    try {
      await fetch("/api/conversations", { method: "DELETE" });
      handleNewSession();
      fetchSessions();
      fetchNotes();
      fetchReminders();
    } catch {}
  };

  // --- Note & Reminder handlers ---
  const handleDeleteNote = async (id: number) => {
    try {
      await fetch(`/api/notes?id=${id}`, { method: "DELETE" });
      fetchNotes();
    } catch {}
  };

  const handleToggleReminder = async (id: number, completed: boolean) => {
    try {
      await fetch("/api/reminders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id, completed }),
      });
      fetchReminders();
    } catch {}
  };

  const handleDeleteReminder = async (id: number) => {
    try {
      await fetch(`/api/reminders?id=${id}`, { method: "DELETE" });
      fetchReminders();
    } catch {}
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden flex flex-col bg-slate-950 text-slate-100 bg-grid-pattern">
      {/* 1. Futuristic Top Header Bar */}
      <Header
        mode={mode}
        onModeChange={(m) => setMode(m)}
        quality={quality}
        onQualityChange={handleQualityChange}
        systemStatus={systemStatus}
        isMuted={isMuted}
        onToggleMute={() => {
          setIsMuted(!isMuted);
          if (!isMuted) stopSpeaking();
        }}
        onOpenSettings={() => setIsSettingsOpen(true)}
        onNewSession={handleNewSession}
        onToggleSidebar={() => setIsSidebarOpen(!isSidebarOpen)}
      />

      {/* 2. Main Stage: Geometric Hologram + Telemetry Panels */}
      <main className="relative flex-1 w-full h-full flex overflow-hidden">
        {/* Left Expandable Conversation Sidebar */}
        <ConversationSidebar
          isOpen={isSidebarOpen}
          onClose={() => setIsSidebarOpen(false)}
          sessions={sessions}
          activeSessionId={activeSessionId}
          onSelectSession={handleSelectSession}
          onNewSession={handleNewSession}
          onDeleteSession={handleDeleteSession}
          onClearAll={handleClearAllMemory}
          notes={notesList}
          onDeleteNote={handleDeleteNote}
          reminders={remindersList}
          onToggleReminder={handleToggleReminder}
          onDeleteReminder={handleDeleteReminder}
        />

        {/* Center: The Geometric Holographic Entity */}
        <div className="relative flex-1 w-full h-full flex items-center justify-center">
          <GeometricHologram
            state={hologramState}
            quality={quality}
            onTap={() => {
              if (!isListening) {
                startListening();
              } else {
                stopListening();
              }
            }}
          />

          {/* Floating Spoken Response Panel (In front of Hologram) */}
          <FloatingResponsePanel
            lastUserMessage={lastUserMessage}
            lastAssistantMessage={lastAssistantMessage}
            interimTranscript={interimTranscript}
            isListening={isListening}
            isThinking={isProcessing}
            isSpeaking={isSpeaking}
            onSpeakText={(txt) => speak(txt)}
            onStopSpeaking={stopSpeaking}
          />
        </div>

        {/* Right Side: Real-Time Audio Spectrum & System Diagnostics */}
        <SystemDiagnostics
          hologramState={hologramState}
          activeTool={activeTool}
          activeTimer={activeTimer}
          onClearTimer={() => setActiveTimer(null)}
          isOpen={isDiagnosticsOpen}
        />
      </main>

      {/* 3. Bottom Controls: Centered Microphone + Text Fallback + Prompt Shortcuts */}
      <BottomControls
        isListening={isListening}
        isSpeaking={isSpeaking}
        voiceError={voiceError}
        onStartListening={startListening}
        onStopListening={stopListening}
        onSendMessage={handleSendMessage}
        onStopSpeaking={stopSpeaking}
        language={speechLanguage}
        onLanguageChange={setSpeechLanguage}
        continuousMode={continuousMode}
        onToggleContinuous={() => setContinuousMode(!continuousMode)}
        disabled={isProcessing}
      />

      {/* 4. Settings & API Configuration Modal */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        systemStatus={systemStatus}
        onRefreshStatus={refreshSystemStatus}
        customGeminiKey={customGeminiKey}
        onSaveGeminiKey={handleSaveGeminiKey}
        customTavilyKey={customTavilyKey}
        onSaveTavilyKey={handleSaveTavilyKey}
        selectedModel={selectedModel}
        onSelectModel={handleSelectModel}
        wakeWord={wakeWord}
        onSaveWakeWord={handleSaveWakeWord}
        wakeWordEnabled={wakeWordEnabled}
        onToggleWakeWord={handleToggleWakeWord}
        speechRate={speechRate}
        onChangeSpeechRate={setSpeechRate}
        speechPitch={speechPitch}
        onChangeSpeechPitch={setSpeechPitch}
        availableVoices={availableVoices}
        selectedVoice={selectedVoice}
        onSelectVoice={setSelectedVoice}
      />
    </div>
  );
}
