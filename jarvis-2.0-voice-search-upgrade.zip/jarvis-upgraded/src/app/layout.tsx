import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "JARVIS 2.0 | Advanced Geometric Holographic AI Personal Assistant",
  description: "Next-generation personal AI entity with living 3D procedural geometric body, Hindi-English voice interaction, live internet search, and expandable tool calling system.",
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className="dark">
      <body className="bg-slate-950 text-slate-100 antialiased selection:bg-cyan-500 selection:text-slate-950 overflow-hidden">
        {children}
      </body>
    </html>
  );
}
