import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { reminders } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const allReminders = await db.select().from(reminders).orderBy(desc(reminders.createdAt)).limit(50);
    return NextResponse.json({ reminders: allReminders });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { text, dueTime } = await req.json();
    if (!text || !dueTime) {
      return NextResponse.json({ error: "Text and dueTime are required" }, { status: 400 });
    }
    const [newReminder] = await db.insert(reminders).values({
      text,
      dueTime,
      completed: false,
    }).returning();

    return NextResponse.json({ reminder: newReminder });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, completed } = await req.json();
    if (!id) {
      return NextResponse.json({ error: "Reminder ID required" }, { status: 400 });
    }
    const [updated] = await db.update(reminders).set({
      completed: Boolean(completed),
    }).where(eq(reminders.id, parseInt(id, 10))).returning();

    return NextResponse.json({ reminder: updated });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) {
      return NextResponse.json({ error: "Reminder ID required" }, { status: 400 });
    }
    await db.delete(reminders).where(eq(reminders.id, parseInt(id, 10)));
    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
