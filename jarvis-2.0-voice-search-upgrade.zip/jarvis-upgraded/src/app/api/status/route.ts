import { NextResponse } from "next/server";
import { db } from "@/db";
import { conversations } from "@/db/schema";

export async function GET() {
  const startTime = Date.now();
  let dbStatus: 'connected' | 'error' = 'connected';

  try {
    await db.select().from(conversations).limit(1);
  } catch (err) {
    console.error("DB check error:", err);
    dbStatus = 'error';
  }

  const hasGeminiKey = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 5);
  const hasTavilyKey = Boolean(process.env.TAVILY_API_KEY && process.env.TAVILY_API_KEY.trim().length > 5);
  const geminiModel = process.env.GEMINI_MODEL || "gemini-3.8-flash";

  return NextResponse.json({
    aiStatus: hasGeminiKey ? 'connected' : 'not_configured',
    aiModel: geminiModel,
    searchStatus: hasTavilyKey ? 'connected' : 'not_configured',
    databaseStatus: dbStatus,
    latencyMs: Date.now() - startTime,
    timestamp: new Date().toISOString(),
  });
}
