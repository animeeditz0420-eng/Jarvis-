import { NextRequest, NextResponse } from "next/server";
import { performTavilySearch } from "@/services/search/tavilySearch";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { query, apiKey, maxResults } = body;

    if (!query || typeof query !== "string") {
      return NextResponse.json({ error: "Search query is required" }, { status: 400 });
    }

    const searchResponse = await performTavilySearch({
      query,
      apiKey,
      maxResults: maxResults || 5,
    });

    return NextResponse.json(searchResponse);
  } catch (error: any) {
    return NextResponse.json(
      { error: error.message || "Failed to execute search" },
      { status: 500 }
    );
  }
}
