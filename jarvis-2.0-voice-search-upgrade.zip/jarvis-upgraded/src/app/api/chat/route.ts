import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages, notes, reminders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { generateGeminiResponse } from "@/services/ai/geminiClient";
import { performTavilySearch } from "@/services/search/tavilySearch";
import { executeSafeCalculator, executeDateTime } from "@/services/tools/jarvisTools";
import { SourceCitation, ToolCallData } from "@/types/jarvis";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      message,
      conversationId: reqConversationId,
      mode = "assistant",
      history = [],
      language = "auto",
      customGeminiKey,
      customTavilyKey,
      customModel,
    } = body;

    if (!message || typeof message !== "string" || !message.trim()) {
      return NextResponse.json({ error: "Message content cannot be empty" }, { status: 400 });
    }

    const trimmedMessage = message.trim();
    const lower = trimmedMessage.toLowerCase();

    // 1. Ensure conversation exists in DB
    let conversationId = reqConversationId;
    if (!conversationId) {
      try {
        const title = trimmedMessage.slice(0, 40) + (trimmedMessage.length > 40 ? "..." : "");
        const [newConv] = await db.insert(conversations).values({
          title,
          mode,
        }).returning({ id: conversations.id });
        conversationId = newConv?.id;
      } catch (e) {
        console.error("Failed to create conversation in DB:", e);
      }
    }

    // 2. Save user message to DB
    if (conversationId) {
      try {
        await db.insert(messages).values({
          conversationId,
          role: "user",
          content: trimmedMessage,
          language,
        });
      } catch (e) {
        console.warn("Could not save user message to DB:", e);
      }
    }

    // 3. Intent Detection & Tool Execution
    let toolData: ToolCallData | undefined;
    let searchResults: SourceCitation[] = [];
    let searchPerformed = false;

    // A. Calculator detection
    const calcMatch = trimmedMessage.match(/(?:calculate|solve|what is|kitna hoga|hisab karo|compute)\s+([0-9+\-*/()., %^eE\sMathPIsqrtincoanpwbslg×÷]+)/i) ||
      (trimmedMessage.match(/^([0-9+\-*/()., %^eE\sMathPIsqrtincoanpwbslg×÷]+)$/) && /[+\-*/×÷%^]/.test(trimmedMessage) ? [null, trimmedMessage] : null);

    if (calcMatch && calcMatch[1]) {
      const calcResult = executeSafeCalculator(calcMatch[1].trim());
      toolData = {
        toolName: "calculator",
        input: { expression: calcMatch[1].trim() },
        output: calcResult,
        status: calcResult.success ? "executed" : "failed",
      };
    }

    // B. Date & Time detection
    else if (
      /(?:what time|current time|aaj kya din hai|date kya hai|what is the date|current date|samay kya hai|time batao)/i.test(lower)
    ) {
      const dtResult = executeDateTime();
      toolData = {
        toolName: "datetime",
        input: {},
        output: dtResult,
        status: "executed",
      };
    }

    // C. Timer detection
    else if (
      /(?:set a timer|timer lagao|timer for|countdown for)\s+(\d+)\s*(seconds?|sec|minutes?|min|ghante|hours?)/i.test(lower)
    ) {
      const timerMatch = lower.match(/(?:set a timer|timer lagao|timer for|countdown for)\s+(\d+)\s*(seconds?|sec|minutes?|min|ghante|hours?)/i);
      if (timerMatch) {
        let sec = parseInt(timerMatch[1], 10);
        const unit = timerMatch[2];
        if (unit.startsWith("min")) sec *= 60;
        else if (unit.startsWith("hour") || unit.startsWith("ghant")) sec *= 3600;

        toolData = {
          toolName: "timer",
          input: { seconds: sec, label: trimmedMessage },
          output: { durationSeconds: sec, status: "active", message: `Timer initialized for ${sec} seconds.` },
          status: "executed",
        };
      }
    }

    // D. Note creation
    else if (/(?:take a note|save note|note banao|note karo|write note):?\s*(.+)/i.test(lower)) {
      const noteMatch = trimmedMessage.match(/(?:take a note|save note|note banao|note karo|write note):?\s*(.+)/i);
      const noteContent = noteMatch ? noteMatch[1].trim() : trimmedMessage;
      try {
        const [savedNote] = await db.insert(notes).values({
          title: noteContent.slice(0, 30),
          content: noteContent,
          tags: "jarvis,voice",
        }).returning();

        toolData = {
          toolName: "notes",
          input: { action: "save", content: noteContent },
          output: { success: true, noteId: savedNote?.id, content: noteContent },
          status: "executed",
        };
      } catch (e) {
        console.warn("Note save failed:", e);
      }
    }

    // E. Reminder creation
    else if (/(?:remind me to|reminder lagao|yaad dilao|set reminder for)\s+(.+?)(?:\s+(?:at|in|on|ko)\s+(.+))?$/i.test(lower)) {
      const remMatch = trimmedMessage.match(/(?:remind me to|reminder lagao|yaad dilao|set reminder for)\s+(.+?)(?:\s+(?:at|in|on|ko)\s+(.+))?$/i);
      const remText = remMatch ? remMatch[1].trim() : trimmedMessage;
      const dueTime = remMatch && remMatch[2] ? remMatch[2].trim() : "Soon";

      try {
        const [savedRem] = await db.insert(reminders).values({
          text: remText,
          dueTime,
          completed: false,
        }).returning();

        toolData = {
          toolName: "reminder",
          input: { text: remText, dueTime },
          output: { success: true, reminderId: savedRem?.id, text: remText, dueTime },
          status: "executed",
        };
      } catch (e) {
        console.warn("Reminder save failed:", e);
      }
    }

    // F. Website opener detection (requires user confirmation in frontend)
    else if (/(?:open website|open|kholo)\s+(https?:\/\/[^\s]+|github|youtube|wikipedia|google|stackoverflow|reddit)/i.test(lower)) {
      const siteMatch = lower.match(/(?:open website|open|kholo)\s+(https?:\/\/[^\s]+|github|youtube|wikipedia|google|stackoverflow|reddit)/i);
      let targetUrl = "";
      let siteName = "";

      if (siteMatch) {
        const matched = siteMatch[1].toLowerCase();
        if (matched.startsWith("http")) {
          targetUrl = matched;
          siteName = new URL(matched).hostname;
        } else if (matched.includes("github")) {
          targetUrl = "https://github.com";
          siteName = "GitHub";
        } else if (matched.includes("youtube")) {
          targetUrl = "https://youtube.com";
          siteName = "YouTube";
        } else if (matched.includes("wikipedia")) {
          targetUrl = "https://wikipedia.org";
          siteName = "Wikipedia";
        } else if (matched.includes("google")) {
          targetUrl = "https://google.com";
          siteName = "Google";
        } else if (matched.includes("stackoverflow")) {
          targetUrl = "https://stackoverflow.com";
          siteName = "Stack Overflow";
        } else if (matched.includes("reddit")) {
          targetUrl = "https://reddit.com";
          siteName = "Reddit";
        }
      }

      if (targetUrl) {
        toolData = {
          toolName: "website_opener",
          input: { url: targetUrl, siteName },
          output: { url: targetUrl, siteName, message: `Permission requested to navigate to ${siteName} (${targetUrl}).` },
          requiresConfirmation: true,
          status: "pending",
        };
      }
    }

    // 4. Web Search Decision
    // If the mode is 'search' or 'research', or user query explicitly mentions search/news/latest/internet/weather/current events
    const needsSearch =
      mode === "search" ||
      mode === "research" ||
      /(?:search|khojo|internet|web search|online|latest|news|aaj|abhi|taaza|khabar|today|tonight|breaking|current|real.?time|live update|recent|who won|release date|weather|mausam|stock|share price|score|result|price|rate|happening now|what happened)/i.test(lower);

    if (needsSearch && (!toolData || toolData.toolName === "website_opener")) {
      // Clean query for search
      let searchQuery = trimmedMessage
        .replace(/jarvis/gi, "")
        .replace(/(?:search|khojo|internet par|search karo|please search|look up|find out)/gi, "")
        .trim();

      if (!searchQuery) searchQuery = trimmedMessage;

      searchPerformed = true;
      const tavilyRes = await performTavilySearch({
        query: searchQuery,
        apiKey: customTavilyKey,
        maxResults: 5,
      });

      if (tavilyRes.status === "success" && tavilyRes.results.length > 0) {
        searchResults = tavilyRes.results;
      } else {
        console.warn("Live search did not return usable results:", tavilyRes.errorMessage || "No results");
        // Do not silently present model memory as if it were live internet data.
        const reason = tavilyRes.errorMessage || "No relevant web results were returned.";
        return NextResponse.json({
          text: `I could not complete a live web search. ${reason} Please check the Tavily key in Settings and try again.`,
          sources: [],
          searchPerformed: true,
          searchStatus: tavilyRes.status,
          searchError: reason,
          conversationId,
        });
      }
    }

    // 5. Generate AI Response via Gemini
    const aiResponse = await generateGeminiResponse(
      trimmedMessage,
      history,
      {
        searchResults,
        toolOutput: toolData?.output,
        mode,
      },
      customGeminiKey,
      customModel
    );

    // 6. Save assistant message to DB
    if (conversationId) {
      try {
        await db.insert(messages).values({
          conversationId,
          role: "assistant",
          content: aiResponse.text,
          sources: searchResults.length > 0 ? searchResults : null,
          toolData: toolData ? { toolName: toolData.toolName, input: toolData.input, output: toolData.output } : null,
          language,
        });
      } catch (e) {
        console.warn("Could not save assistant message to DB:", e);
      }
    }

    return NextResponse.json({
      text: aiResponse.text,
      sources: searchResults,
      toolData,
      modelUsed: aiResponse.modelUsed,
      source: aiResponse.source,
      conversationId,
      searchPerformed,
      searchStatus: searchPerformed ? "success" : "not_requested",
      searchError: null,
    });
  } catch (error: any) {
    console.error("Chat API error:", error);
    return NextResponse.json(
      { error: error.message || "An unexpected error occurred in JARVIS core." },
      { status: 500 }
    );
  }
}
