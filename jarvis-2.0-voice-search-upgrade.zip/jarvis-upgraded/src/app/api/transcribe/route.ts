import { NextRequest, NextResponse } from "next/server";

export const runtime = "nodejs";
export const maxDuration = 30;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { audioBase64, mimeType, language = "auto", apiKey: customApiKey } = body || {};

    if (typeof audioBase64 !== "string" || !audioBase64.trim()) {
      return NextResponse.json({ error: "Audio data is required." }, { status: 400 });
    }
    if (audioBase64.length > 4_000_000) {
      return NextResponse.json({ error: "Recording is too large. Please speak for a shorter time (under about 30 seconds)." }, { status: 413 });
    }

    const apiKey = (typeof customApiKey === "string" && customApiKey.trim()) || process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return NextResponse.json({
        error: "Android voice transcription needs a Gemini API key. Open JARVIS Settings, add your free-tier Gemini key, and save it.",
      }, { status: 401 });
    }

    const safeMime = typeof mimeType === "string" && /^audio\/(webm|mp4|ogg|wav|mpeg|mp3)/i.test(mimeType)
      ? mimeType.split(";")[0]
      : "audio/webm";
    const model = process.env.GEMINI_TRANSCRIPTION_MODEL || process.env.GEMINI_MODEL || "gemini-3.8-flash";
    const promptByLanguage: Record<string, string> = {
      hi: "Transcribe the audio accurately in Hindi using Devanagari script. Preserve English technical words in Latin script when naturally spoken. Return only the transcription.",
      en: "Transcribe the audio accurately in English. Return only the transcription.",
      auto: "Transcribe the speech accurately. The speaker may use Hindi, English, or Hinglish in the same sentence. Preserve Hindi words in Devanagari and English words in Latin script where appropriate. Do not translate or summarize. Return only the words actually spoken.",
      hinglish: "Transcribe the speech accurately as Hinglish. Keep Hindi words in Devanagari and English words in Latin script where appropriate. Do not translate or summarize. Return only the words actually spoken.",
    };

    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-goog-api-key": apiKey,
        },
        body: JSON.stringify({
          contents: [{
            role: "user",
            parts: [
              { text: promptByLanguage[language] || promptByLanguage.auto },
              { inlineData: { mimeType: safeMime, data: audioBase64 } },
            ],
          }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 512 },
        }),
        signal: AbortSignal.timeout(25_000),
      }
    );

    const raw = await upstream.text();
    let data: any = {};
    try { data = raw ? JSON.parse(raw) : {}; } catch {}
    if (!upstream.ok) {
      const message = data?.error?.message || `Gemini transcription returned HTTP ${upstream.status}.`;
      return NextResponse.json({ error: message }, { status: upstream.status === 429 ? 429 : 502 });
    }

    const transcript = (data?.candidates?.[0]?.content?.parts || [])
      .map((part: any) => part.text || "")
      .join("")
      .trim();

    if (!transcript) {
      return NextResponse.json({ error: "No clear speech was detected in the recording. Please try again." }, { status: 422 });
    }

    return NextResponse.json({ transcript, modelUsed: model });
  } catch (error: any) {
    console.error("Voice transcription error:", error);
    return NextResponse.json(
      { error: error?.name === "TimeoutError" ? "Voice transcription timed out. Please try a shorter recording." : error?.message || "Voice transcription failed." },
      { status: 500 }
    );
  }
}
