import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { desc, eq, asc } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const conversationId = searchParams.get("id");

    if (conversationId) {
      const convMessages = await db
        .select()
        .from(messages)
        .where(eq(messages.conversationId, conversationId))
        .orderBy(asc(messages.createdAt));

      return NextResponse.json({ messages: convMessages });
    }

    const allConversations = await db
      .select()
      .from(conversations)
      .orderBy(desc(conversations.updatedAt))
      .limit(30);

    return NextResponse.json({ conversations: allConversations });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { title = "New Interaction", mode = "assistant" } = await req.json();
    const [newConv] = await db
      .insert(conversations)
      .values({ title, mode })
      .returning();

    return NextResponse.json({ conversation: newConv });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (id) {
      await db.delete(conversations).where(eq(conversations.id, id));
    } else {
      // Clear all
      await db.delete(messages);
      await db.delete(conversations);
    }

    return NextResponse.json({ success: true });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
